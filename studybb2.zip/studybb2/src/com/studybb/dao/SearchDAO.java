package com.studybb.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.studybb.exception.NotFoundException;
//import com.studybb.vo.Member;
import com.studybb.vo.Study;

public class SearchDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public List<Study> selectBySearch(String study_area, int study_type,String study_tag) throws NotFoundException {

		List<Study> list = new ArrayList<Study>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "STUDYBB";
			String password = "STUDYBB";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = /*
								 * "SELECT S.STUDY_TITLE,S.STUDY_PRICE,S.STUDY_WEEK,M.MEM_NAME,S.STUDY_UPLOAD\r\n"
								 * + "from STUDY S JOIN MEMBER M ON S.MEM_ID = M.MEM_ID\r\n" +
								 * "WHERE (REGEXP_LIKE(STUDY_TAG, '취업|컴공')) AND (STUDY_AREA = '인천') AND (STUDY_TYPE = 0)\r\n"
								 * + "ORDER BY STUDY_UPLOAD DESC";
								 */
					"SELECT STUDY_TITLE,STUDY_PRICE,STUDY_WEEK,MEM_ID,STUDY_UPLOAD\r\n" + //
					"from STUDY \r\n" + 
					"WHERE (REGEXP_LIKE(STUDY_TAG, ?)) ";
			//if(전체가 아닐때) {
			if(!"전체".equals(study_area)) {	 
				selectSQL += "AND (STUDY_AREA = '" + study_area + "')\r\n";
			} 
			
			if(study_type != 2) {
				
				selectSQL += "AND (STUDY_TYPE = " + study_type + ")\r\n";
			} 
//			if(좋아요 일때)
//				selectSQL += "ORDER BY STUDY_LIKES DESC";
//			else
				selectSQL += "ORDER BY STUDY_UPLOAD DESC";
			pstmt = con.prepareStatement(selectSQL);
			pstmt.setString(1,study_tag);
			//pstmt.setString(2, study_area);
			//pstmt.setInt(3, study_type);
			rs = pstmt.executeQuery();	
			while (rs.next()) {
				//Member m = new Member();
				String setStudy_title=rs.getString("STUDY_TITLE");
				System.out.println("in searchDAO study_title:" + setStudy_title);
				int setStudy_price = rs.getInt("STUDY_PRICE");
				int setStudy_week = rs.getInt("STUDY_WEEK");
				//m.setMem_name(rs.getString("mem_name");
				String setmem_id = rs.getString("MEM_ID");
				Date setStudy_upload = rs.getDate("STUDY_UPLOAD");
				Study study = new Study(setStudy_title,setStudy_price,setStudy_week,setmem_id,setStudy_upload);
				// 대입
				list.add(study);
				
			}
			if(list.size() == 0) {
				throw new NotFoundException("검색결과가 없습니다.");
			}
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
		return list;
		
	}
	
	public void closeConnection() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
