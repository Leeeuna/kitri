package com.studybb.vo;

import java.util.Date;

public class Study {
	private int study_no;
	private String mem_id;
	private String study_leader_intro;
	private String study_title;
	private String study_area;
	private Date study_start;
	private int study_week;
	private Date study_due;
	private String study_content;
	private String study_tag;
	private Date study_upload;
	private int study_type;
	private int study_price;
	private int study_cap;
	


	public Study() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Study(int study_no,  String mem_id, String study_leader_intro, String study_title, String study_area,
			Date study_start, int study_week, Date study_due, String study_content, String study_tag, Date study_upload,
			int study_type, int study_price, int study_cap) {
		super();
		this.study_no = study_no;
		this.mem_id = mem_id;
		this.study_leader_intro = study_leader_intro;
		this.study_title = study_title;
		this.study_area = study_area;
		this.study_start = study_start;
		this.study_week = study_week;
		this.study_due = study_due;
		this.study_content = study_content;
		this.study_tag = study_tag;
		this.study_upload = study_upload;
		this.study_type = study_type;
		this.study_price = study_price;
		this.study_cap = study_cap;
	}
	public Study(String study_title,int study_price,int study_week, String mem_id, Date study_upload) {
		super();
		this.study_title = study_title;
		this.study_price = study_price;
		this.study_week = study_week;
		this.mem_id = mem_id;
		this.study_upload = study_upload;
	}
	
	
	
	public int getStudy_no() {
		return study_no;
	}

	public void setStudy_no(int study_no) {
		this.study_no = study_no;
	}

	public String getmem_id() {
	    return mem_id;
	}

	public void setmem_id(String mem_id) {
		this.mem_id = mem_id;
	}


	public String getStudy_leader_intro() {
		return study_leader_intro;
	}

	public void setStudy_leader_intro(String study_leader_intro) {
		this.study_leader_intro = study_leader_intro;
	}

	public String getStudy_title() {
		return study_title;
	}

	public void setStudy_title(String study_title) {
		this.study_title = study_title;
	}

	public String getStudy_area() {
		return study_area;
	}

	public void setStudy_area(String study_area) {
		this.study_area = study_area;
	}

	public Date getStudy_start() {
		return study_start;
	}

	public void setStudy_start(Date study_start) {
		this.study_start = study_start;
	}

	public int getStudy_week() {
		return study_week;
	}

	public void setStudy_week(int study_week) {
		this.study_week = study_week;
	}

	public Date getStudy_due() {
		return study_due;
	}

	public void setStudy_due(Date study_due) {
		this.study_due = study_due;
	}

	public String getStudy_content() {
		return study_content;
	}

	public void setStudy_content(String study_content) {
		this.study_content = study_content;
	}

	public String getStudy_tag() {
		return study_tag;
	}

	public void setStudy_tag(String study_tag) {
		this.study_tag = study_tag;
	}

	public Date getStudy_upload() {
		return study_upload;
	}

	public void setStudy_upload(Date study_upload) {
		this.study_upload = study_upload;
	}

	public int getStudy_type() {
		return study_type;
	}

	public void setStudy_type(int study_type) {
		this.study_type = study_type;
	}

	public int getStudy_price() {
		return study_price;
	}

	public void setStudy_price(int study_price) {
		this.study_price = study_price;
	}

	public int getStudy_cap() {
		return study_cap;
	}

	public void setStudy_cap(int study_cap) {
		this.study_cap = study_cap;
	}

}