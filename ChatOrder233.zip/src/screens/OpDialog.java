package screens;

import java.awt.Frame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import dataClass.Order;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.DefaultComboBoxModel;

public class OpDialog extends JDialog{
	
	private Order order;
	String str = "";
	
	public OpDialog(Frame frame, String title) {
		
		super(frame, title, true);
		setSize(261,408);
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\uC0AC\uC774\uC988");
		label.setBounds(22, 61, 46, 15);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\uC218\uB7C9");
		label_1.setBounds(22, 99, 46, 15);
		getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("\uC628\uB3C4");
		label_2.setBounds(22, 141, 46, 15);
		getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("\uB2F9\uB3C4");
		label_3.setBounds(22, 184, 46, 15);
		getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("\uC5BC\uC74C\uB7C9");
		label_4.setBounds(22, 266, 46, 15);
		getContentPane().add(label_4);
		
		JCheckBox ckTall = new JCheckBox("Tall");
		ckTall.setBounds(76, 57, 54, 23);
		getContentPane().add(ckTall);
		
		JCheckBox ckGrande = new JCheckBox("Grande");
		ckGrande.setBounds(143, 57, 76, 23);
		getContentPane().add(ckGrande);
		
		JCheckBox ckice = new JCheckBox("Ice");
		ckice.setBounds(76, 137, 54, 23);
		getContentPane().add(ckice);
		
		String[] count = {"1","2","3","4","5","6","7","8","9","10"};
		JComboBox combobox = new JComboBox(count);
		combobox.setToolTipText("");
		combobox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		
		combobox.setMaximumRowCount(10);
		combobox.setBounds(80, 96, 50, 21);
		getContentPane().add(combobox);
		
		JCheckBox ckhot = new JCheckBox("Hot");
		ckhot.setBounds(143, 137, 54, 23);
		getContentPane().add(ckhot);
		
		JCheckBox ckless = new JCheckBox("\uC801\uAC8C");
		ckless.setBounds(76, 180, 54, 23);
		getContentPane().add(ckless);
		
		JCheckBox ckregular = new JCheckBox("\uBCF4\uD1B5");
		ckregular.setBounds(143, 180, 54, 23);
		getContentPane().add(ckregular);
		
		JCheckBox ckmany = new JCheckBox("\uB9CE\uC774");
		ckmany.setBounds(76, 221, 54, 23);
		getContentPane().add(ckmany);
		
		JCheckBox ck0 = new JCheckBox("0%");
		ck0.setBounds(76, 262, 54, 23);
		getContentPane().add(ck0);
		
		JCheckBox ck50 = new JCheckBox("50%");
		ck50.setBounds(143, 262, 54, 23);
		getContentPane().add(ck50);
		
		JCheckBox ck100 = new JCheckBox("100%");
		ck100.setBounds(76, 301, 68, 23);
		getContentPane().add(ck100);
		
		JButton setbutton = new JButton("\uD655\uC778");
		setbutton.setBounds(165, 336, 68, 23);
		getContentPane().add(setbutton);

		
		setbutton.addActionListener(new ActionListener() {	// Ȯ�ι�ư ������ ����������
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(ckTall.isSelected()) {
					str = str + ckTall.getText() + "/";
				}
				
				if(ckGrande.isSelected()) {
					str = str + ckGrande.getText() + "/";
				}
				
				int count = Integer.parseInt((String) combobox.getSelectedItem());
				str = str + count + "/";
				
				
				if(ckice.isSelected()) {
					str = str + ckice.getText() + "/";
					
				}
				
				if(ckhot.isSelected()) {
					str = str + ckhot.getText() + "/";
					
				}
				
				if(ckless.isSelected()) {
					str = str + ckless.getText() + "/";
					
				}
				
				if(ckregular.isSelected()) {
					str = str + ckregular.getText() + "/";
					
				}
				
				if(ckmany.isSelected()) {
					str = str + ckmany.getText() + "/";
					
				}
				
				if(ck0.isSelected()) {
					str = str + ck0.getText();
					
				}
				
				if(ck50.isSelected()) {
					str = str + ck50.getText();
					
				}
				
				if(ck100.isSelected()) {
					str = str + ck100.getText();
					
				}

				setVisible(false);
		
			}
		});
		
	}
	

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	public String getInput() {
		return str;
	}

}
	
