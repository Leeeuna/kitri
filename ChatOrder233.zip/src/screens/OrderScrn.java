package screens;

import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

import db.OrderConnect;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class OrderScrn {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public OrderScrn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("������ - �ֹ���Ȳ ������");
		frame.getContentPane().setFont(new Font("����", Font.PLAIN, 17));
		frame.setBounds(100, 100, 785, 512);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 65, 747, 399);
		frame.getContentPane().add(scrollPane);

		OrderConnect oc = new OrderConnect(scrollPane);
		oc.getOrderList();
		
		JButton refreshButton = new JButton("\uC0C8\uB85C\uACE0\uCE68");
		refreshButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���ΰ�ħ ��ư ������
				OrderConnect newOc = new OrderConnect(scrollPane);
				newOc.getOrderList();
			}
		});
		refreshButton.setBounds(645, 10, 114, 45);
		frame.getContentPane().add(refreshButton);
		
		JLabel lblNewLabel = new JLabel("    \uC811\uC218\uB41C \uC8FC\uBB38");
		lblNewLabel.setBounds(12, 10, 627, 45);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("��������", Font.BOLD, 25));
		lblNewLabel.setToolTipText("\uC811\uC218\uB41C \uC8FC\uBB38");
	}
}
