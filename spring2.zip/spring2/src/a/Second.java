package a;

public interface Second {
	String info();
}
