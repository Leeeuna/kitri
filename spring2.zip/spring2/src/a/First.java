package a;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.*;

@Component
public class First {
	private String msg;

//	@Autowired				//클래스타입에 일치하는 객체찾기
//	private Second second; //Second객체가 없어서 자동주입 실패시 NoSuchBeanDefinitionException발생
							//Second객체가 없어서 자동 주입 실패시 null로 유지하려면
							//@Autowired(required = false)로 설정한다
							//Seocond객체가 여러개이면 자동주입 실패시 NoUniqueBeanDefinitionException발생
	@Autowired
	@Qualifier("s1")
	private Second second;
	
	private boolean flag;
	
	@PostConstruct
	public void init() {
		System.out.println("init method호출");
		flag=true;
	}
	
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String toString() {
		return "msg=" + msg + ", second.info()=" + second.info();
	}
}
