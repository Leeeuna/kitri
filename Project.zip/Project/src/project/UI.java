package project;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import java.awt.SystemColor;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class UI {

   private JFrame frame;
   private JTextField textField;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
            	UI window = new UI();
               window.frame.setVisible(true);
            
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the application.
    */
   public UI() {
      try {
         initialize();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   
   
   
   /**
    * Initialize the contents of the frame.
    */
   private void initialize() throws Exception {
      final List<String> message = new LinkedList<String>();
      
      frame = new JFrame("ä�� �ֹ� ����: ChatOrder!");
      frame.setBounds(100, 100, 338, 533);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().setLayout(null);
      
      JPanel titlePanel = new JPanel();
      titlePanel.setBackground(SystemColor.activeCaption);
      titlePanel.setBounds(0, 21, 322, 51);
      frame.getContentPane().add(titlePanel);
      titlePanel.setLayout(new BorderLayout(0, 0));
      
      JLabel label = new JLabel("\uC8FC\uBB38\uD558\uAE30");
      label.setHorizontalAlignment(SwingConstants.CENTER);
      titlePanel.add(label, BorderLayout.CENTER);
      
      JPanel chatPanel = new JPanel();
      chatPanel.setBounds(0, 72, 322, 320);
      frame.getContentPane().add(chatPanel);
      chatPanel.setLayout(null);
      
      JTextArea textArea = new JTextArea();
      textArea.setBounds(0, 0, 322, 320);
      chatPanel.add(textArea);
      
      textArea.append("[*]:\t�ȳ��ϼ���. ��Ÿ�����Դϴ�\n");

      JPanel inputPanel = new JPanel();
      inputPanel.setBounds(0, 428, 322, 66);
      frame.getContentPane().add(inputPanel);
      inputPanel.setLayout(null);
      
      textField = new JTextField();
      textField.setBounds(0, 0, 261, 66);
      inputPanel.add(textField);
      textField.setColumns(10);
      
      JPanel buttonPanel = new JPanel();
      buttonPanel.setBackground(SystemColor.inactiveCaption);
      buttonPanel.setBounds(0, 392, 322, 36);
      frame.getContentPane().add(buttonPanel);
      
      JButton sendButton = new JButton("\uC804\uC1A1");
      sendButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            // ����� �Է� ���
            textArea.append("[�����]: ");
            
            // �Էµ� �ؽ�Ʈ�� getMessage �Լ��� ����: ��� ��ư ó���� ���� �Լ�
            Message.setMessage(textField.getText());
            
            // textField�� �Է� ������ ���
            textArea.append(textField.getText() + "\n");
            
            // ���� ��ü�� �������ִ� ����
            synchronized (message) {
                   message.add(textField.getText());
                   message.notify();
               }
            frame.dispose();
         }
      });
      

          
      sendButton.setBounds(260, 0, 62, 66);
      inputPanel.add(sendButton);
      
      JToolBar toolBar = new JToolBar();
      toolBar.setToolTipText("Admin page");
      toolBar.setBounds(0, 0, 322, 17);
      frame.getContentPane().add(toolBar);
      

      abstract class select{
    	  public String kind;

    	  
    	  public abstract void data();
	}
      
      
      abstract class no1 extends select{
    	  public no1() {
    		  this.kind = "����";
    	  }
    	  @Override
    	  public void data() {
    		  String str;
    		  str = message.get(0);
    		  if(message != null) {
        		  textArea.append(str);
    		  }
    	  
      }
}
   
      
//      // Button set
//      JButton button1_1 = new JButton("����ũ�ƿ�");
//      button1_1.addActionListener(new ActionListener() {
//         public void actionPerformed(ActionEvent e) {
//            // �Էµ� �ؽ�Ʈ�� getMessage �Լ��� ����
//            Message.setMessage("����ũ�ƿ�");
//            // �Է� ������ ���
//            textArea.append("[�����]: ����ũ�ƿ�\n");
//         }
//      });
//      button1_1.setBounds(10, 325, 97, 23);
//      
//      JButton button1_2 = new JButton("����");
//      button1_2.setBounds(119, 325, 97, 23);
//      button1_2.addActionListener(new ActionListener() {
//         public void actionPerformed(ActionEvent e) {
//            // �Էµ� �ؽ�Ʈ�� getMessage �Լ��� ����
//            Message.setMessage("����");
//            // �Է� ������ ���
//            textArea.append("[�����]: ����\n");
//         }
//      });
//      
//      boolean isFalse = false;
//      // �ֹ� flow ����
//      while(!isFalse) {
//         textArea.append("\n[*]:\t���忡�� ��ðڽ��ϱ�?\n\tTakeOut �Ͻðڽ��ϱ�?\n\t��ư�� ���� �������ּ���!\n");
//         buttonPanel.add(button1_1);
//         buttonPanel.add(button1_2);
//      
//         // �޼��� �޾ƿ���
//         synchronized (message) {
//
//            String str;
//              // wait for input from field
//              while (message.isEmpty()) {
//                  message.wait();
//              }
//              str = message.get(0);
//              message.clear();
//              
//              textArea.append(str);
//          }
//         break;
//      }
      
      
   }
}