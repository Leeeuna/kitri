import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Test {

	public static void main(String[] args) {
		A a = new A();
		a.setStr("test");
		a.setNum(123);
		a.setFlag(true);
		
		ObjectMapper mapper = new ObjectMapper();
		
		
		try {
			//POJO -> JSONString
			String jsonStr = mapper.writeValueAsString(a);
			System.out.println(jsonStr);
			
			//JSONString -> POJO
			A a1 = mapper.readValue(jsonStr, A.class);
			System.out.println(a1.getStr() + ":" + a1.getNum() + ":" + a1.isFlag());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<A> list = new ArrayList<>();
		for(int i = 1; i<=5; i++) {
		A a2 = new A();
		a2.setNum(1);
		list.add(a2);
		}
		try {
			String listJsonStr = mapper.writeValueAsString(list);
			System.out.println(listJsonStr);
			
			List<A> list1 = mapper.readValue(listJsonStr, new TypeReference<List<A>>() {});
			for(A a3: list1) {
				System.out.println(a3.getNum());
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
