package chatting;

import javax.swing.JFrame;

class DialogEx extends JFrame {
	// private MyDialog dialog;

//	public DialogEx() {
//	      super("dialogEx ������");
//	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	      JButton btn = new JButton("�ɼ��� �����ּ���");
//
//	      getContentPane().add(btn);
//	      setSize(250,200);
//	   //   setVisible(true);
//	      
//	   }
}