package dataClass;

public class Order {
	
	private int orderNum;			// �ֹ���ȣ
	private int itemNum;			// ��ǰ��ȣ
	private String itemName;		// ��ǰ�̸�
	private String category;		// ī�װ���
	private int price;				// ����
	private boolean isTakeout;		// ����/����ũ�ƿ�
	private String cupSize;			// ������
	private String options;			// �µ�/�絵/������
	private String orderDate;		// �ֹ���¥
	private boolean isComplete;		// �ֹ��Ϸ� ����
	private int count;				// ����
	
	// getter setter
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public int getItemNum() {
		return itemNum;
	}
	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}
	public boolean getIsTakeout() {
		return isTakeout;
	}
	public void setIsTakeout(boolean isTakeout) {
		this.isTakeout = isTakeout;
	}
	public String getCupSize() {
		return cupSize;
	}
	public void setCupSize(String cupSize) {
		this.cupSize = cupSize;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public boolean getIsComplete() {
		return isComplete;
	}
	public void setIsComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}

