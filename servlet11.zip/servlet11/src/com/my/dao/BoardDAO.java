package com.my.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.my.exception.NotFoundException;
import com.my.vo.Board;


public class BoardDAO {

	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public int count() throws NotFoundException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = "SELECT COUNT(*) FROM board";
			pstmt = con.prepareStatement(selectSQL);
			rs = pstmt.executeQuery();
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
	}
	
	public List<Board> select(int startRow, int endRow) throws NotFoundException {

		List<Board> list = new ArrayList<Board>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = "SELECT a.*\r\n" + 
					"FROM\r\n" + 
					"    (SELECT rownum rn, level, board.*\r\n" + 
					"    FROM board\r\n" + 
					"    START WITH parent_no IS NULL\r\n" + 
					"    CONNECT BY PRIOR board_no = parent_no\r\n" + 
					"    ORDER SIBLINGS BY board_no DESC) a\r\n" + 
					"WHERE a.rn BETWEEN ? AND ?";
			pstmt = con.prepareStatement(selectSQL);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();	
			while (rs.next()) {
				int board_no = rs.getInt("board_no");
				int parent_no = rs.getInt("parent_no");
				int level = rs.getInt("level");
				String board_subject = rs.getString("board_subject");
				String board_writer = rs.getString("board_writer");
				String board_content = rs.getString("board_content");
				Date board_time = rs.getDate("board_time");
				String board_pwd = rs.getString("board_pwd");
				
				// 대입
				Board board = new Board(board_no, parent_no, level, 
						board_subject, board_writer, board_content, board_time, board_pwd);
				list.add(board);
			}
			if(list.size() == 0) {
				throw new NotFoundException("게시목록이 없습니다.");
			}
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
		return list;
		
	}
	
	public Board selectByBoardNo(int no, String mode) throws NotFoundException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = "SELECT * FROM board WHERE board_no = ?";
			pstmt = con.prepareStatement(selectSQL);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();	

			if (rs.next()) {
				int board_no = rs.getInt("board_no");
				int parent_no = rs.getInt("parent_no");
				String board_subject = rs.getString("board_subject");
				String board_writer = rs.getString("board_writer");
				String board_content = rs.getString("board_content");
				Date board_time = rs.getDate("board_time");
				String board_pwd = rs.getString("board_pwd");

				Board board = new Board(board_no, parent_no, 
						board_subject, board_writer, board_content, board_time);
				
				if(mode.equals("edit"))	
					board.setBoard_pwd(board_pwd);
				
				return board;
			}
			throw new NotFoundException("게시목록이 없습니다.");
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
	}
	
	public void insert(Board board) throws NotFoundException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = "INSERT INTO board(BOARD_NO, PARENT_NO, BOARD_SUBJECT, "
					+ "BOARD_WRITER, BOARD_CONTENT, BOARD_TIME, BOARD_PWD) "
					+ "VALUES (board_seq.NEXTVAL, ?, ?, ?, ?, SYSDATE, ?)";
			pstmt = con.prepareStatement(selectSQL);
			if(board.getParent_no() == 0) {
				pstmt.setObject(1, null);
			} else {

				pstmt.setInt(1, board.getParent_no());
			}
			pstmt.setString(2, board.getBoard_subject());
			pstmt.setString(3, board.getBoard_writer());
			pstmt.setString(4, board.getBoard_content());
			pstmt.setString(5, board.getBoard_pwd());
			rs = pstmt.executeQuery();	
			if (rs.next()) {
				return;		
			}
			throw new NotFoundException("게시물 등록 실패");
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
	}
	
	public void closeConnection() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
