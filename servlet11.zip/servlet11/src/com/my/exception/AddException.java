package com.my.exception;

public class AddException extends Exception {

	public AddException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
