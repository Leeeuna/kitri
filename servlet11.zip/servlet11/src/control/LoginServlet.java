package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.my.dao.CustomerDAO;
import com.my.exception.NotFoundException;
import com.my.service.CustomerService;
import com.my.vo.Customer;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerService service; // 공유객체

	public LoginServlet() {
		service = new CustomerService();
	}

	// private CustomerService service = new CustomerService(); //여러사용자
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*--아이디 기억 --
		String c = request.getParameter("c");
		if("save".equals(c)) { //아이디 기억
			//1)쿠키생성
			Cookie cookie = new Cookie("savedId", request.getParameter("id"));
			//2)쿠키유효기간설정
			cookie.setMaxAge(60);//1분간 사용가능한 쿠키
			//3)쿠키 응답헤더에 추가
			response.addCookie(cookie);
		}else {//아이디 기억해제
			//1)쿠키생성
			Cookie cookie = new Cookie("savedId", request.getParameter("id"));
			//2)쿠키유효기간설정
			cookie.setMaxAge(0);//0초간 사용가능한 쿠키-기존쿠키 무효화
			//3)쿠키 응답헤더에 추가
			response.addCookie(cookie);
		}*/
		/*-----------------------------------------------------------*/
		
		HttpSession session = request.getSession();
		session.removeAttribute("loginInfo");
		
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");

		String str = service.login(id, pwd);
		
		/*--로그인 성공시 HttpSession객체의 속성으로 추가 --*/
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(str);
			JSONObject jsonObj = (JSONObject)obj;
			if((Long)jsonObj.get("status") ==1) {//로그인 성공된 케이스
				
				session.setAttribute("longinInfo", id);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.setAttribute("result", str);

		String path = "/result.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);

		// 1.응답형식 지정하기. MIME값 활용
		// String str = "{\"status\":" + state + ",\"id\": \"" + id +"\"}";
//		response.setContentType("text/html;charset=utf-8");
//		//2.응답출력스트림 얻기
//		PrintWriter out = response.getWriter();
//		//3.응답하기	
//		out.print(str);

	}
}
