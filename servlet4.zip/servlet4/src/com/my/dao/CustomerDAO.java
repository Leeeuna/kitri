package com.my.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.my.exception.NotFoundException;
import com.my.vo.Customer;
import com.my.vo.Post;

public class CustomerDAO {
	//고객정보 : id,pwd,name,buildingno,addr
	
	public Customer selectById(String id) throws NotFoundException{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String loginSQL = "SELECT * FROM customer WHERE id=?";
			pstmt = con.prepareStatement(loginSQL);
			pstmt.setString(1, id);
			rs  = pstmt.executeQuery();
			if(rs.next()) {  //if(rs.next()==true)
				Customer c = new Customer();
				c.setId(rs.getString("id"));
				c.setPwd(rs.getString("pwd"));
				c.setName(rs.getString("name"));
				Post p = new Post();
				p.setBuildingno(rs.getString("buildingno"));
				c.setPost(p);
				c.setAddr(rs.getString("addr"));
				return c;
			}
			throw new NotFoundException("아이디가 존재하지 않습니다.");
		}catch(Exception e) {
			throw new NotFoundException(e.getMessage());
		}finally {
			if(rs != null) 
				try {
					rs.close();
				}catch(SQLException e) {}
			if(pstmt != null) 
				try {
				pstmt.close();
				}catch(SQLException e) {}
			if(con != null) 
				try {
					con.close();
				}catch(SQLException e) {}
		}
		
		
	}
	public int InsertCustomer(String id,String pwd,String name,String buildingno,String addr) throws NotFoundException{
		Connection con = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user = "C##ORACLE_USER";
				String password = "dmsk";
	
				con = DriverManager.getConnection(url, user, password);
				String selectsubmitSQL = "insert into customer values(?,?,?,?,?)";
				pstmt = con.prepareStatement(selectsubmitSQL);
				pstmt.setString(1, id);
				pstmt.setString(2, pwd);
				pstmt.setString(3, name);
				pstmt.setString(4, buildingno);
				pstmt.setString(5, addr);
				rs  = pstmt.executeUpdate();

//				if(rs.next()) { 
//					String id = rs.getString("id");
//					String pwd = rs.getString("pwd");
//					String name = rs.getString("name");
//					String buildingno = rs.getString("buildingno");
//					String addr2 = rs.getString("addr2");
//					result += "{\"id\":\""+ id +"\",\"pwd\":\""+ pwd+"\",\"name\":\"" + name + "\", \"buildingno\":\""+ buildingno+"\",\"addr2\":\"" + addr2 + "\"}";
//				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
//				if(rs != 0) 
//					try {
//						rs.close();
//					}catch(SQLException e) {}
				if(pstmt != null) 
					try {
					pstmt.close();
					}catch(SQLException e) {}
				if(con != null) 
					try {
						con.close();
					}catch(SQLException e) {}
			}return rs;
			
		
	}
	
	//void insert(Customer c){
	//	 	throws AddException{
	//	try{
	//
	//	}catch(ClassNotFoundException e){
	//	throw new AddException(e.getMessage());
	//	}catch(SQLException e){
	//	throw new AddException(e.getMessage());
	//	}finally{
	//DB연결닫기
	//	}
	//}
	
	
}
