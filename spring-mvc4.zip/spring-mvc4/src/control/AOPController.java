package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import javax.management.RuntimeErrorException;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.my.dao.AccountDAO;

@Controller
public class AOPController {
	//@Autowired
	//private SqlSession sqlSession;
//	@Autowired
//	private DataSource dataSource;
	@Autowired
	private AccountDAO dao;
	
	@GetMapping("/account")
	@ResponseBody
	//@Transactional(propagation = Propagation.REQUIRED)
	public String account() { //mybatis없이 db연결가능
		dao.account();
		
		
		
		
//		HashMap<String, Object> map = new HashMap<>();
//		map.put("no", "101");
//		map.put("amount", "10");
//		int rowCnt1 = sqlSession.update("com.my.vo.Account.withdraw",map);
//		if(rowCnt1 ==0) {
//			throw new RuntimeException("출금오류");
//		}
//		map = new HashMap<>();
//		//map.put("no","102");
//		map.put("no","999");
//		map.put("amount","10");
//		int rowCnt2 =sqlSession.update("com.my.vo.Account.deposit",map);
//		if(rowCnt2 == 0) {
//			throw new RuntimeException("입금오류");
//		}
		
		
		
		
		
//		//service.XX();
//		Connection con = null;
//		PreparedStatement pstmt1 = null;
//		PreparedStatement pstmt2 = null;
//		try {
//			con = dataSource.getConnection();
//			con.setAutoCommit(false);
//			String sql1 = "UDATE account SET balance= balance-10 WHRER no=?";
//			pstmt1 = con.prepareStatement(sql1);
//			pstmt1.setString(1, "101");//101번계좌에서 10원 출금
//			int rowCnt1 = pstmt1.executeUpdate();//성공
//			
//			String sql2 = "UDATE account SET balance= balance+10 WHRER no=?";
//			pstmt2 = con.prepareStatement(sql2);
//			//pstmt2.setString(1, "102");//102번계좌로 10원 입금
//			pstmt2.setString(1, "999");//999번계좌로 10원 입금 무시
//			int rowCnt2 = pstmt2.executeUpdate();//무시
//			
//			if(rowCnt1==1 && rowCnt2 ==1) {
//				con.commit();
//			}else {
//				con.rollback();
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			try {
//				con.rollback();
//			} catch (SQLException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		}
		return "계좌이체";
	}
}
