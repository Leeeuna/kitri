package chatting;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import java.awt.SystemColor;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import dataClass.MessageBox;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class ChatScrn {
	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChatScrn window = new ChatScrn();
					window.frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChatScrn() {
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws Exception {

		MessageBox mes = new MessageBox();

		frame = new JFrame("ä�� �ֹ� ����: ChatOrder!");
		frame.setBounds(0, 0, 460, 630);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);

		JPanel titlePanel = new JPanel();
		titlePanel.setBackground(SystemColor.activeCaption);
		titlePanel.setBounds(0, 21, 445, 51);
		frame.getContentPane().add(titlePanel);
		titlePanel.setLayout(new BorderLayout(0, 0));

		JLabel label = new JLabel("\uC8FC\uBB38\uD558\uAE30");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		titlePanel.add(label, BorderLayout.CENTER);

		JPanel inputPanel = new JPanel();
		inputPanel.setBounds(0, 525, 445, 66);
		frame.getContentPane().add(inputPanel);
		inputPanel.setLayout(null);

		textField = new JTextField();
		textField.setBounds(0, 0, 350, 66);
		inputPanel.add(textField);
		textField.setColumns(10);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(SystemColor.inactiveCaption);
		buttonPanel.setBounds(0, 489, 445, 36);
		frame.getContentPane().add(buttonPanel);

		JToolBar toolBar = new JToolBar();
		toolBar.setToolTipText("Admin page");
		toolBar.setBounds(0, 0, 445, 17);
		frame.getContentPane().add(toolBar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 71, 445, 422);
		frame.getContentPane().add(scrollPane);

		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
		
		JButton sendButton = new JButton("\uC804\uC1A1");
		sendButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str = textField.getText();
				if (!str.equals("")) {

					// textField�� �Է� ������ ���
					textArea.append("[�����]: " + str + "\n");

					// ����� �Է��� �޾� �����ϴ� thread ����
					InputThread rt = new InputThread(textField, mes);
					rt.start();
				}
			}
		});
		sendButton.setBounds(350, 0, 95, 66);
		inputPanel.add(sendButton);

		// ���� Ű �Է� �� ���� ��ư�� ������ �۵�
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String str = textField.getText();
					if (!str.equals("")) {

						// textField�� �Է� ������ ���
						textArea.append("[�����]: " + str + "\n");

						// ����� �Է��� �޾� �����ϴ� thread ����
						InputThread rt = new InputThread(textField, mes);
						rt.start();
					}
				}
			}

		});

		textArea.append("[*]:\t�ȳ��ϼ���. ��Ÿ�����Դϴ�\n");
		
		// ����� �Է¿� ���� ��� ��ƾ thread ����
		PrintThread pt = new PrintThread(textArea, mes, frame);
		pt.start();
	}
}
