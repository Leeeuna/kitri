package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.service.CustomerService;

public class SearchZipServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	private CustomerService service; //공유객체
	public SearchZipServlet() {
		service = new CustomerService();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String doro = request.getParameter("doro");
	    
		String zipcode = request.getParameter("zipcode");
		String addrdoro = request.getParameter("addrdoro");
		String addrzibun = request.getParameter("addrzibun");
		String buildingno = request.getParameter("buildingno");
				
				String str = service.searchZip(doro);
				request.setAttribute("result", str);
			    String path = "result";
				RequestDispatcher rd = request.getRequestDispatcher(path);
				rd.forward(request, response);

			}

		}