package javajdbc;

import java.sql.*;

public class QueryDB {

   public static void main(String[] args) {
      
      String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
      String DB_USER = "c##oracle_user";
      String DB_PW = "dmsk";
      
      Connection conn = null;
      Statement stmt = null;
      ResultSet rs = null;
      
      String query = "select * from emp";
      
      // ����̹� -> 
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
      } catch (ClassNotFoundException e) {}
      
      try {
         conn = DriverManager.getConnection(
               DB_URL, 
               DB_USER, 
               DB_PW);
         stmt = conn.createStatement();
         rs = stmt.executeQuery(query);
         
         while (rs.next()) {
            String name = rs.getString(2);
            System.out.println(name);
         }
      } catch (Exception e) {}
      finally {
         try {
         rs.close();
         stmt.close();
         conn.close();
         } catch (SQLException e) {
            
         }   
      }
   }
}

