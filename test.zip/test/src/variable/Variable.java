package variable;

public class Variable {
	public static void main(String[] arg) {
		//����
		byte by =1;//1 =8bit=256
		short sh =2; //2
		int in =4;//4
		long lo =8;//8
		//�Ǽ�
		float fl =4;//4
		double dou =8.8;//8
		
		in=in+2;
		System.out.println(by);
		System.out.println(sh);
		System.out.println(in);
		System.out.println(lo);
		
		dou=dou+0.2;
		System.out.println(fl);
		System.out.println(dou);
		//����
		char ch='a';
		System.out.println(ch);
		//������
		boolean bool = true;
		System.out.println(bool);
	}
}
