package variable;

public class PromotionEx {
	public static void main(String[] arg) {
		//Ÿ�Ժ���
		int a = 10;
		int b = 20;//����
		
		double douA = 20;
		double douB =0;//�Ǽ���
		
		douB = douA + (double) a;
		//20.0 + 10.0
		//System.out.println(douB);
	
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
	}
}
