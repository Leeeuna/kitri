package variable;

public class Operater {
	public static void main(String[] arg) {
		int a = 10;
		a += 5;
		System.out.println(a);
		
		a -= 5;
		System.out.println(a);
		
		a *= 5;
		System.out.println(a);
		
		a /= 5;
		System.out.println(a);
		
		a %= 5;
		System.out.println(a);
	}
}
