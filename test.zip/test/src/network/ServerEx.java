package network;

import java.io.*;

import java.net.*;


public class ServerEx {
	public static void main(String[] args) {
		ServerSocket serversocket = null;
		
		try {
			serversocket = new ServerSocket();
			//����õ�
			//System.out.println("Client : connect�õ�");
			serversocket.bind(new InetSocketAddress("192.168.30.150",5001));
			
			while(true) {
				System.out.println("�����ٸ�");
				Socket socket = serversocket.accept();
				InetSocketAddress isa = (InetSocketAddress) socket.getRemoteSocketAddress();
				System.out.println("���� ������ " +isa.getHostName());
			
			
			byte[] bytes = null;
			String message =null;
			
			InputStream is = socket.getInputStream();
			int readSize = is.read(bytes);
		
			message = new String(bytes, 0 ,readSize, "UTF-8");
			System.out.println("�����͹ޱ� ���� : " + message);
			
			
			OutputStream os = socket.getOutputStream();
			message = "Hello Client";
			bytes = message.getBytes("UTF-8");
			
			os.write(bytes);
			os.flush();
			System.out.println("�����ͺ����⼺��");
			
			is.close();
			os.close();
			socket.close();
			}
		}catch(Exception e) {
			System.out.println("�����������");
		}
		if(!serversocket.isClosed()) {
			try {
				serversocket.close();
			}catch(IOException e1) {}
		}
	}
}
