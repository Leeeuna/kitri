package network;

import java.net.InetAddress;

public class InetAdderssEx {
	public static void main(String[] args) {
		try {
			InetAdderess local = InetAddress.getLocalHost();
		}
	}
}
