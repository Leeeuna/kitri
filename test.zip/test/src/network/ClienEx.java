package network;

import java.io.*;
import java.net.*;

public class ClienEx {
	public static void main(String[] args) {
		Socket socket = null;
		
		try {
			socket = new Socket();
			//����õ�
			System.out.println("Client : connect�õ�");
			socket.connect(new InetSocketAddress("192.168.30.150",5001));
			
			//����Ϸ�
			System.out.println("Client : connect�Ϸ�");
			
			byte[] bytes = null;
			String message =null;
			
			OutputStream os = socket.getOutputStream();
			message = "I am Client";
			bytes = message.getBytes("UTF-8");
			os.write(bytes);
			os.flush();
			System.out.println("�۽ſϷ�");
			
			InputStream is = socket.getInputStream();
			bytes = new byte[100];
			
			int readSize = is.read(bytes);
			message = new String(bytes, 0 ,readSize, "UTF-8");
			System.out.println("�����͹ޱ� ���� : " + message);
			
			os.close();
			is.close();
			
		}catch(Exception e) {
			System.out.println("�����������");
		}
		if(!socket.isClosed()) {
			try {
				socket.close();
			}catch(IOException e1) {}
		}
	}
}
