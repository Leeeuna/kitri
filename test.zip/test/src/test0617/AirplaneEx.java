package test0617;

public class AirplaneEx {
	public static void main(String[] args) {
		superAirplane sa = new superAirplane();
		sa.fly();
		sa.flymode = superAirplane.SUPERSONIC;
		sa.fly();
	}
}
