package Exercise13;

class Exercise6 {
	
	static double sumArea(Shape[] arr) {
		double result = 0;
		for(int i = 0; i <arr.length; i++) {
			result += arr[i].calcArea();
			}
		return result;
	}
	
	public static void main(String[] args) {
		Shape[] arr = {new Circle(5.0), new Rectangle(3,4), new Circle(1)};
		System.out.println("������ ��: "+ sumArea(arr));
	}
}


abstract class Shape {
	Point p;
	Shape(){
		this(new Point(0,0));
	}
	
	Shape(Point p){
		this.p = p;
	}
	abstract double calcArea();
	
	Point getPosition() {
		return p;
	}
	
	void setPosition(Point p) {
		this.p = p;
	}
	

}

class Circle extends Shape{
	final double PI = 3.14;
	double r;
	
	Circle(double r){
		this.r = r;
	}
	public double calcArea() {
		return r * r * PI;
	}
	
}

class Rectangle extends Shape{
	double width = 0;
	double height = 0;
	
	Rectangle(double width, double height){
		this.width = width;
		this.height = height;
	}
	public double calcArea() {
		return width * height;
	}
	
	public boolean isSquare() {
		boolean result = false;
		if(width == height) 
			result = true;
		return result;
	}
}

class Point{
	int x;
	int y;
	Point(){
		this(0,0);
	}
	
	Point(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public String toString() {
		return "[" + x + "," + y +"]";
	}
}