package Exercise13;

class MyTv {
	private boolean isPowerOn;
	private int channel;
	private int volume;
	final int MAX_VOLUME = 100;
	final int MIN_VOLUME = 0;
	final int MAX_CHANNEL = 100;
	final int MIN_CHANNEL = 1;
	private int[] prevChannel = new int[100];
	private int index = 0;
	private int pointer = 0;
	
	public boolean isPowerOn() {
		return isPowerOn;
	}
	
	public void setPowerOn(boolean isPowerOn) {
		this.isPowerOn = isPowerOn;
	}
	
	public void setChannel(int channel) {
		this.channel = channel;
		prevChannel[index] = channel;
		index++;
	}
	public int getChannel() {
		return channel;
	}
	
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public int getVolume() {
		return volume;
	}
	
	public void gotoPrevChannel(){
		setChannel(prevChannel[pointer]);
		pointer++;
	}
}

class Exercise1{
	public static void main(String[] args) {
		MyTv t = new MyTv();	
		t.setChannel(10);
		System.out.println("CH : "+ t.getChannel());		
		t.setVolume(20);
		System.out.println("VOL : "+ t.getVolume());
	}
}

class Exercise2{
	public static void main(String[] args) {
		MyTv t = new MyTv();
		t.setChannel(10);
		System.out.println("CH : " + t.getChannel());
		
		t.setChannel(20);
		System.out.println("CH : " + t.getChannel());
		
		t.gotoPrevChannel();
		System.out.println("CH : " + t.getChannel());
		
		t.gotoPrevChannel();
		System.out.println("CH : " + t.getChannel());
	}
}