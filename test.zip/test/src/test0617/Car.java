package test0617;

public class Car {
	String master;
	String model = "Sonata";
	int speed;
	int cc;
	int maxspeed;
	
	Car(){
		System.out.println("Car()");
	}
	
	Car(String master){
		System.out.println("master�� ");
		this.master = master;
		this.cc = 2000;
		this.maxspeed = 200;
	}
	Car(String master,int cc){
		this(master);
		this.cc = 2000;
		
	}
	
	void run() {
		System.out.println("run");
		speed = speed + 10;
	}

	void speedCheck(){
		System.out.println(speed);
	}
}
