package test0617;

public class A {
	A(){
		System.out.println("A()");
	}
	void methodA() {
		System.out.println("A");
	}
}

class B extends A{
	B(){
		System.out.println("B()");
	}
	@Override
	void methodA() {
		System.out.println("BA");
	}
	void methodB(){
			System.out.println("B");
	}
}

class C extends A{
	void methodC(){
			System.out.println("C");
	}
}

class D extends B{
	void methodD(){
			System.out.println("D");
	}
}
class E extends C{
	void methodE(){
			System.out.println("E");
	}
}