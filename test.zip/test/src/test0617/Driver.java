package test0617;

public class Driver {
	void driver(Vehicle vehicle) {
		vehicle.run();
	}
}
