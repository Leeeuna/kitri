package test0617;
class Account {
	private int balance;
	static final int MIN_BALANCE = 0;
	static final int MAX_BALANCE = 1000000;

	Account(){
		balance = 0;
	}
	void setBalance(int balance) {
		int tmp = 0;
		tmp = this.balance + balance;
		if(balance < MIN_BALANCE || balance > MAX_BALANCE) {
			this.balance = balance;
		}else {
			this.balance = tmp;
		}
	}
	
	int getBalance() {
		return this.balance;
	}
}
