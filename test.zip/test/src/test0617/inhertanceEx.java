package test0617;

public class inhertanceEx {
	public static void main(String[] args) {
//		Texi seoulTexi = new Texi();
//		System.out.println(seoulTexi.master);
//		seoulTexi.run();
//		seoulTexi.run();
//		seoulTexi.run();
//		seoulTexi.run();
//		seoulTexi.run();
//		seoulTexi.calPrice(10);
//		System.out.println(seoulTexi.totalPrice);
		
		
		SCV scv1 = new SCV();
		SCV scv2 = new SCV();
//		
//		System.out.println("scv1 " + scv1.hp);
//		System.out.println("scv2 " + scv2.hp);
//		scv1.attack(scv2);
//		
//		System.out.println("scv1 " + scv1.hp);
//		System.out.println("scv2 " + scv2.hp);
//		
//		scv1.fix(scv2);
//		System.out.println("scv1 " + scv1.hp);
//		System.out.println("scv2 " + scv2.hp);
		scv1.stop();
	}
}
