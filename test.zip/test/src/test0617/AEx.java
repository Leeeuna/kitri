package test0617;

public class AEx {
	public static void main(String[] args) {
//		A a = new A();
//		B b = new B();
//		C c = new C();
//		D d = new D();
//		E e = new E();
		
		A a = new B(); //�ڵ� ����ȯ
		
		boolean result = false;
		result = a instanceof B;
		System.out.println(result);
		
		if(result == true) {
			B b = (B)a; //���� ����ȯ
			b.methodA();
			b.methodB();
		}else {
			System.out.println("��������ȯ�� �� �� �����ϴ�.");
		}
//		a.methodA();
//		a=b;
//		a.methodA();
//		a=c;
//		a.methodA();
//		a=d;
//		a.methodA();
//		a=e;
//		a.methodA();
//		
//		b=d;
//		b.methodA();
//		b.methodB();
//		c=e;
//		c.methodA();
//		c.methodC();
		
	}
}
