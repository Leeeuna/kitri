package test0617;

public class Airplane {
	public void land() {
		
	}
	
	public void fly() {
		System.out.println("�Ϲ� ����");
	}
	
	public void takeoff() {
		
	}
}


