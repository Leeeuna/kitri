package Thread;

public class Threadjoin {
	public static void main(String[] args) {
		sumThread sth = new sumThread();
		sth.start();
		
		try {
			sth.join();//wait ���� : sth�������
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println(sth.sum);
	}
}

class sumThread extends Thread{
	long sum = 0;
	
	public void run() {
		for(int i = 0; i <= 100; i++) {
			this.sum += i;
		}
	}
}
