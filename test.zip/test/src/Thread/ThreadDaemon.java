package Thread;

public class ThreadDaemon {
	public static void main(String[] args) {
		AutoSave1 autosave = new AutoSave1();
		autosave.setDaemon(true);
		autosave.start();
		
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			
		}
		System.out.println("auto save �մϴ�.");
	}
}

public class AutoSave1 extends Thread{
	public void save(){
		System.out.println("�۾� ������ ����");
	}
	
	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				break;
			}
			save();
		}
	}
}