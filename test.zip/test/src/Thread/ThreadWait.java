package Thread;

public class ThreadWait {
	public static void main(String[] args) {
		WorkObject shareObj = new WorkObject();
		
		ThreadA ta = new ThreadA(shareObj);
		ThreadB tb = new ThreadB(shareObj);
		ta.start();
		tb.start();
	}
}

class ThreadA extends Thread{
	private WorkObject workObj;
	ThreadA(WorkObject workObj){
		this.workObj = workObj;
	}
	public void run() {
		for(int i = 0; i < 10; i++) {
			workObj.methodA();
		}
	}
	
}

class ThreadB extends Thread{
	private WorkObject workObj;
	ThreadB(WorkObject workObj){
		this.workObj = workObj;
	}
	public void run() {
		for(int i = 0; i < 10; i++) {
			workObj.methodB();
		}
	}
	
}

class WorkObject{
	synchronized void methodA() {
		System.out.println("methodA ȣ��");
		notify();
		try {
			wait();	
		}catch(InterruptedException e) {
	
		}
	}
	
	synchronized void methodB() {
		System.out.println("methodB ȣ��");
		notify();
		try {
			wait();	
		}catch(InterruptedException e) {
	
		}
	}
}