package Thread;

public class TreadEx {
	public static void main(String[] args) {
		Thread t1 = new BeepThread();
		t1.setPriority(Thread.MAX_PRIORITY);
		t1.start();

		Runnable r1 = new BeepThread2();
		Thread t2 = new Thread(r1);
		t2.setPriority(Thread.MIN_PRIORITY);
		t2.start();
	}
}


class BeepThread2 implements Runnable{
	@Override
	public void run() {
		for(int i = 0; i < 100; i++) {
			System.out.println("ȣ");
			try {
				Thread.sleep(1000);
				
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
	}
}
}

class BeepThread extends Thread{
	@Override
	public void run() {
		for(int i = 0; i < 100; i++) {
			System.out.println("��");
		}
	}
}
