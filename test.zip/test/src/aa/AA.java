package aa;
import bb.BB;

public class AA {
	int valueA = 1;
	
	void method() {
		BB.vlaueB = 3;
	}
}
