package gengeric_inheritance;

public class Storageimpl<T> implements Storage<T> {
	
	private T[] array;
	
	public Storageimpl(int cap) {
		this.array = (T[])(new Object[cap]);
	}
	
	public void add(T item , int index) {
		array[index] = item;
	}
	public T get(int index) {
		return array[index];
	}
}
