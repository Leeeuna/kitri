package gengeric_inheritance;

public class ContainerEx2 {

	   public static void main(String[] args)
	   {

		  Container2<String, String> container11 = new Container2<String,String>();//Ȯ�ι��� 3
		  container11.set("ȫ�浿","����");
	      String name1 = container11.getKey();
	      String job = container11.getValue();
	      //Ȯ�ι��� 3

	      Container2<String, Integer> container12 = new Container2<String,Integer>();
	      container12.set("ȫ�浿",35);
	      String name2 = container12.getKey();
	      int age = container12.getValue();
		   //Ȯ�ι��� 3
		   
		   }
		}