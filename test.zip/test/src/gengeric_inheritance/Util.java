package gengeric_inheritance;

public class Util {
	public static <P extends Pair<K,V>, K, V> V getValue(P p, K key) {
		V result;
		if(key == p.getKey()) {
			result = p.getValue();
		}
		else {
			result = null;
		}
		return result;
	}
}
