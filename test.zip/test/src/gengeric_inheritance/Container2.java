package gengeric_inheritance;

class Container2<T,M>{
   private T name;
   private M value;
   public void set(T t, M m)
   {
      this.name = t;
      this.value = m;
   }

   public T getKey()
   {
      return name;
   }
   public M getValue()
   {
      return value;
   }
}
