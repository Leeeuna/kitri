package gengeric_inheritance;

public class InheritanceEx {
	public static void main(String[] args) {
		ChildProduct<String, String, String> cp = new ChildProduct<>();
		
		cp.setKind("TV");
		cp.setModel("SmartTV");
		cp.setCompany("Samsung");
	}
}
