package test0620linkedList;

public class LinkedlistEx {
	public static void main(String[] args) {
		Linkedlist list = new Linkedlist();
		list.firstNode(10);
		list.addRearNode(20);
		list.printData();
		list.removeAllNode();
		
	}
}
