package test0620nestedClass.instansceMemberClass;

public class MessageListener {

}
