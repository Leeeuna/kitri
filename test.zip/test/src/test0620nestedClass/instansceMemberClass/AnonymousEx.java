package test0620nestedClass.instansceMemberClass;

public class AnonymousEx {
	public static void main(String[] args) {
		Anonymous an = new Anonymous();
		an.person.wake();
		
		an.method();
		
		an.method2(new Person() {
			void study() {
				System.out.println("study");
			}
			void wake() {
				study();
				System.out.println("wake");
			}
		}
		);
	}
}
