package test0620nestedClass.instansceMemberClass;

public interface Vehicle {
	public void run();
	
}
