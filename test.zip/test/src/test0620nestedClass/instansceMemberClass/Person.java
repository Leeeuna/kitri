package test0620nestedClass.instansceMemberClass;

public class Person {
	void work() {}
	void wake() {
		System.out.println("Wake");
	}
//	void walk() {
//		System.out.println("Walk");
//	}
}
