package test0620nestedClass.instansceMemberClass;

public class Outter {
	String outter = "Outter field";
	
	void method() {
		System.out.println("Outter.method()");
	}

	void print() {
		System.out.println(this.outter);		
		this.method();
	}
	
	class NestedClass{
		String nested = "nested field";
		
		void method() {
			System.out.println("NestedClass.Method()");
		}
		
		void print() {
			System.out.println(this.nested);		
			this.method();
			
			System.out.println(Outter.this.outter);		
			Outter.this.method();
			}
	}
}
