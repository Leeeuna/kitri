package test0620nestedClass.instansceMemberClass;

public class Anonymous {
	Person person = new Person() {
	void walk() {
		System.out.println("Walk");
	}
	};
	
	void method() {
		Person localVar = new Person() {
			void work() {
				System.out.println("Work");
			}
			
			void wake() {
				work();
				System.out.println("Wake");
			}
		};
		localVar.work();
		localVar.wake();
	}
	
	void method2(Person pcerson) {
		person.wake();
	}
}
