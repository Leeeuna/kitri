package test0620nestedClass.instansceMemberClass;

public class Car {
	class Tire{}
	static class Engine{}
}
