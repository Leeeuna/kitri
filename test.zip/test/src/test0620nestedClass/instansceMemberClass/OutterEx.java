package test0620nestedClass.instansceMemberClass;

public class OutterEx {
	public static void main(String[] args) {
		Outter outter = new Outter();
		Outter.NestedClass nested = outter.new NestedClass();
		
		System.out.println(outter.outter);
		outter.method();
		outter.print();
		System.out.println(nested.nested);
		nested.method();
		nested.print();
	}
}
