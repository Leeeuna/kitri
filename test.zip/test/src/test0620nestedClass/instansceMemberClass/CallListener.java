package test0620nestedClass.instansceMemberClass;

public class CallListener {
	public void onClick() {
		System.out.println("��ȭ�� �̴ϴ�.");
	}
}
