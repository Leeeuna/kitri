package access2;

import access.A;

public class C {
	A a1 = new A(true);
	A a2 = new A(1);
	A a3 = new A("���ڿ�");
	
	void method() {
		a1.method();
		a1.method2();
		a1.method3();
}
