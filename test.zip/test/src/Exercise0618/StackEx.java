package Exercise0618;

public class StackEx {

	   public static void main(String[] args) {
	      Stack stack = new Stack() {
	         char[] charArr = new char[5];
	         // 1 2 3 4 5
	         // a |
	         int pointer = 0;

	         @Override
	         public boolean push(Object ob) {
	            if (pointer < 5) {
	               charArr[pointer++] = (char) ob;
	            } else {
	               System.out.println("�迭�� ���� ���� �� �����ϴ�.");
	            }
	            return true;
	         }

	         @Override
	         public Object pop() {
	            char result = ' ';
	            if (pointer != 0) {
	               result = charArr[--pointer];
	               charArr[pointer] = ' ';
	            } else {
	               System.out.println("�迭�� ���� �����ϴ�.");
	            }
	            return result;
	         }

	         @Override
	         public Object peek() {
	            char result = ' ';
	            if (pointer != 0) {
	               result = charArr[--pointer];
	               pointer++;
	            } else {
	               System.out.println("�迭�� ���� �����ϴ�.");
	            }
	            return result;
	         }

	         @Override
	         public int length() {
	            return pointer;
	         }
	      };
	      
	      stack.push('a');
	      stack.push('b');
	      stack.push('c');
	      stack.push('d');
	      
	      System.out.println(stack.peek());
	      System.out.println(stack.peek());
	      System.out.println(stack.peek());
	      System.out.println(stack.peek());
	      System.out.println(stack.length());
	   }
	}

