package Exercise0618;

public abstract class Peek implements Stack {

}
