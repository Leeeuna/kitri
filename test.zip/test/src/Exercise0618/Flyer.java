package Exercise0618;

public interface Flyer {
	int fast = 100;
	void fly();
	boolean isAnimal();
}


