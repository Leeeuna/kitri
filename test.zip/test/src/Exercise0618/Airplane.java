package Exercise0618;

public class Airplane implements Flyer{
	public void fly() {
		System.out.println("Airplane flying");
	}
	public boolean isAnimal() {
		System.out.println("false");
		return false;
	}
}
