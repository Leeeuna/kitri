package Exercise0618;

public abstract class Pop implements Stack {

}
