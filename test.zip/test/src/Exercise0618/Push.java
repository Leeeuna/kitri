package Exercise0618;

public abstract class Push implements Stack {

}
