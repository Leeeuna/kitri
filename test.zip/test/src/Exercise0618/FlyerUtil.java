package Exercise0618;

public abstract class FlyerUtil implements Flyer {
	static void show(Flyer f) {
		f.fly();
		f.isAnimal();
	}
}
