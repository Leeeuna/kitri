package Exercise0618;

public class Bird implements Flyer{
	public void fly() {
		System.out.println("Bird flying");
	}
	public boolean isAnimal() {
		System.out.println("true");
		return true;
	}
	
}
