package Exercise0624;

import java.util.StringTokenizer;

public class SplitEx {
	public static void main(String[] args) {
		String str = "���̵�, �̸�, �н�����";
		
		String[] names = str.split(",");
		for(String name : names) {
			System.out.println(name);
		}
		
		System.out.println();
		
		StringTokenizer st = new StringTokenizer(str, ",");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		
	}
}
