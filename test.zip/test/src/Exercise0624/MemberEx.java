package Exercise0624;

public class MemberEx {
	public static void main(String[] args) {
		Member member = new Member("blue", "���Ķ�");
		System.out.println(member);
	}
}
