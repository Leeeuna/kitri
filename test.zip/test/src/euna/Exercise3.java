package euna;

public class Exercise3 {
	public static void main(String[] args) {
		int num = 10;
		System.out.println(num > 0 ? "���" : num < 0 ? "����" : 0);
	}
}
