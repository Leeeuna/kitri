package operation;

public class operator2 {
	public static void main(String[] avg) {
		int a = 10;
		a ++;//11
		++a;//12
		System.out.println(a++);//10
		System.out.println(++a);//12
		int b = 10;
		b--;//9
		--b;//8
		System.out.println(b--);
		System.out.println(--b);
		
		int c = 10;
		++c;
		c--;
		--c;
		--c;
		c++;
		System.out.println(++c);//10
		
		System.out.println(c++);
		System.out.println(c);//10
		
		c=0;
		a=5;
		b=7;
		c= ++a + b++;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
		boolean bool = false;
		System.out.println(!bool);//true
		
		//�񱳿����� > < = >= <= != ==
		boolean b1 = 100 > 20;//true
		boolean b2 = 100 < 20;//false
		int d=20;
		int e=30;
		boolean b3 = d >=e;//f
		boolean b4 = d <=e;//t
		boolean b5 = d !=e;//t
		boolean b6 = d ==e;//f
		System.out.println(b1+ " " + b2 + b3 + b4 + b5 + b6);
		
		//���������� &&(and) ||(or) !(not) ^(nor)
		
		//(������) ? �� : ����
		int f;
		e = 50;
		f = (e == 50) ? 100:200;
		System.out.println(f);
		
		int pencils = 534;
		int students = 30;
		
		int pencilsperstudent = 534/30;
		System.out.println(pencilsperstudent);
		
		int pencilsleft = 534%30;
		System.out.println(pencilsleft);
		
		int value = 356;
		System.out.println((value/100)*100);
		
		int lengthtop=5;
		int lengthbottom=10;
		int height=7;
		double area=(((lengthtop+lengthbottom)* height)/2);
		double area1=(((lengthtop+lengthbottom)* height*100)/(double)200);
		System.out.println(area);
		System.out.println(area1);
		
		
	}
}
