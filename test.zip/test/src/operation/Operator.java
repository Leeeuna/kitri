package operation;

public class Operator {
	public static void main(String[] arg) {
		int a = 10;
		a = a*2;
		a = a*a;
		System.out.println(a);
		a = 10;
		a *= 2;
		a *= a;
		System.out.println(a);
		
		int b = 1;
		b = b + 1;
		System.out.println(b);
		b += 1;
		System.out.println(b);
		b++;
		System.out.println(b);
		b--;
		System.out.println(b);
		
		int p100;//3
		int p10;//6
		int p1;//5
		p100=365/100;
		System.out.println("p100 = " + p100);
		p10=(365-(p100*100)) / 10;
		System.out.println("p10 = " + p10 );
		p1=365%10;
		System.out.println("p1 = " + p1);
		
		//f <= ����µ�
		double F;
		double C = 20;
		F = (C * 9/5) + 32;
		System.out.println("F = " + F);
		
		
		
		
	}
}
