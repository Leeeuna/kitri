package basicApi;

public class StringEx {
	public static void main(String[] args) {
		String str = "abc";
		char ch = 'c';	
		int in = 10;
		
		byte[] bytes = {72,101,108,108,111,13,10};
		String str1 = new String(bytes);
		System.out.print(str1);
		
		
		for(int i = 0; i < str1.length(); i++) {
			char c = str1.charAt(i);
			System.out.println(c);
		}
		
		String str2 = "Monday";
		byte[] str2Bytes;
		try {
			str2Bytes = str2.getBytes();
			for(int i = 0; i < str2Bytes.length; i++) {
				System.out.print(str2Bytes[i] + " ");
			}
			String str3 = new String(str2Bytes);
			System.out.println(str3);
		}catch(Exception e) {
			
		}
		
		String str4 = "ABCDEFGHIJ";
		int index = str4.indexOf("CDE");
		System.out.println("�ε��� : " + index);
		
		String str5 = "�ڹ� ���α׷���";
		String str6 = str5.replace("�ڹ�", "JAVA");
		System.out.println(str6);
		
		String str7 = "880808-1008088";
		String year = str7.substring(0,2);
		String gender = str7.substring(7,8);
		System.out.println(year + " " + gender);
		
		String str8 = "hello java";
		String lowercase = str8.toLowerCase(); 
		String uppercase = str8.toUpperCase();
		System.out.println(lowercase + " " + uppercase);
		
		String strint = String.valueOf(100);
		String strboolean = String.valueOf(true);
		String strdouble = String.valueOf(100.1234);
		char[] charr=	{'h','e','l','l','o'};
		String strCharArr = String.copyValueOf(charr);
		
		System.out.println(strint);
		System.out.println(strboolean);
		System.out.println(strdouble);
		System.out.println(strCharArr);
		
		System.out.println(Integer.valueOf(strint));
		
		
		
	}
}
