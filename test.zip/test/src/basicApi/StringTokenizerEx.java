package basicApi;

import java.util.*;

public class StringTokenizerEx {
	public static void main(String[] args) {
		String str = "this/is/a/test";
		StringTokenizer st = new StringTokenizer(str, " ");
		
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		
		String[] test = str.split("/");
		for(String t : test) {
			System.out.println(t);
		}
	}
}
