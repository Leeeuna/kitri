package basicApi;

public class FinalizeEx {
	public static void main(String[] args) {
		Counter count = new Counter(1);
			System.out.println(count.no);
			
			count = null;
			//System.out.println(count.no);
			System.gc();
	}
}

class Counter{
	int no;
	
	public Counter(int no) {
		this.no = no;
	}
	
	@Override
	protected void finalize() throws Throwable{
		System.out.println(no + "�� ��ü ����");
	}
}