package basicApi;

import java.util.Arrays;

public class ArrayEx {
	public static void main(String[] args) {
		int[] num = {2,3,6,1,5};
		
		Arrays.sort(num);
		for(int number : num) {
			System.out.println(number + " ");
		}
		int index = Arrays.binarySearch(num ,6);
		System.out.println(index);
		
		
		
		String[] names = {"ȫ�浿", "�ڵ���","��μ�"	};
		Arrays.sort(names);
		for(String name : names) {
			System.out.println(name + " ");
		}
		index = Arrays.binarySearch(names, "ȫ�浿");
		
		Member3 name1 =new Member3("ȫ�浿");
		Member3 name2 =new Member3("�ڵ���");
		Member3 name3 =new Member3("��μ�");
		Member3[] memberName = {name1, name2, name3};
		Arrays.sort(memberName);
		for(Member3 mem : memberName) {
			System.out.println(mem.name);
		}
		index = Arrays.binarySearch(memberName, "1");
		System.out.println(index);
	}
}


class Member3 implements Comparable<Member3>{
	
	String name;
	Member3(String name){
		this.name = name;
	}
	@Override
	public int compareTo(Member3 o) {
		// TODO Auto-generated method stub
		return name.compareTo(o.name);
	}
	
}