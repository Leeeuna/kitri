package basicApi;

public class ClassEx {
	public static void main(String[] args) {
		Car car = new Car();
		try {
			Class car1 = Class.forName("basicApi.Car");
			System.out.println(car1.getName());
			System.out.println(car1.getPackage().getName());
			
			Class car2 = car.getClass();
			System.out.println(car2.getName());
			System.out.println(car2.getPackage().getName());
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
}

class Car{
	Car(){
		System.out.println("Car() ������");
	}
}
