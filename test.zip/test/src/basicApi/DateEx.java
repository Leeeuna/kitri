package basicApi;

import java.util.Date;
import java.text.SimpleDateFormat;

public class DateEx {
	public static void main(String[] args) {
		java.util.Date now = new java.util.Date();
		String time = now.toString();
		System.out.println(time);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd. hh:mm:ss");
		System.out.println(sdf.format(now));
		
	}
}
