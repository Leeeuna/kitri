package basicApi;

public class SystemEx {
	public static void main(String[] args) {
	//	System.out.println("hong");
		//long time1 = System.nanoTime();
		long time = System.currentTimeMillis();
		for(int i = 0; i < 100000; i++) {
			if(i != 5) {
				System.out.println(i);
			}else {
				//System.exit(0);
			}
		}
		//long time2 = System.nanoTime();
		long time2 = System.currentTimeMillis();
		//System.out.println(time2 - time);
		
		String username = System.getProperty("user.name");
		String userDir = System.getProperty("user.dir");
		System.out.println(username);
		System.out.println(userDir);
		
	}
}
