package test0614;

public class Car2 {
	String master;
	boolean power;
	String mode;//D����, B�ް���, N�Ϲ�
	int s;
	int g;
	int a;
	int b;
	int m;
	
	Car2(){
		g = 100;
		m = 200;
		s = 0;
		mode = "N";
		power = false;
	}
	
	Car2(String master){
		this();//Car2()������ ȣ��
		if(master == "euna") {
		System.out.println("������"+master);
		power = true;
		}
	}
	
	void transfer(String mode) {
		if(power && (this.mode == "N")&&(mode == "D")) {
			this.mode = mode;//N-> D
		}if(power && (this.mode == "D")&&(mode == "B")) {
			this.mode = mode;//D->B
		}if(power && (this.mode == "N")) {
			this.mode = mode;//D,B -> N
		}else {
			System.out.println("������ �� �� �����ϴ�.");
		}
	}
	
	void booster() {
		if(power && mode == "B") {
			s = 300;
			g -= 20;
			System.out.println("Booster on!");
			for(int i = 0; i < 5; i++) {
				try{
					Thread.sleep(1000);
					System.out.println("Booster : " + (i+1)+ "��");
				}catch(InterruptedException e) {
					e.printStackTrace();
				}//1��
			}
		
		}else {
			System.out.println("�ν��͸�� ���� �ȵ�");
		}
	}
	
	void accel() {
		if(power&& (this.mode)=="D") {
			if((g >= 10) && (s == m)) {
				System.out.println("�ְ��ӵ��Դϴ�.");
			}else if((g >= 10)&&(s < m)) {
					if(s <= (m - 10)) {
						s = s + 10;
						g = g - 10;
					}else {
						s = m;
						g = g - 10;
					} 
				}else {
					System.out.println("�⸧ ����");
				}
		}
	}
	

	
	void gas() {
		if(g == 0) {
			g = g + 100;
		}
		g = g - 10;
	}
	

	
	void stop() {
		if(power) {
			if(s >= 20) {
				s = s - 20;
			}else if((s < 20)&&(s > 0)) {
				s =0;
			}else {
				System.out.println();
			}
		}
	}
	
	
}
