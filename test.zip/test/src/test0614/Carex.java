package test0614;

import test0613.Car;

public class Carex {
	public static void main(String[] arg) {
		Car2 car = new Car2("euna");
		car.mode = "D";
		car.accel();
		System.out.println(car.s);
		
		
//		System.out.println(car.g);
//		System.out.println(car.m);
//		System.out.println(car.s);
//		car.accel();
//		System.out.println(car.s + " "  + car.g);
	}
}
