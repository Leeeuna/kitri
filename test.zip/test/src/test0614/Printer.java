package test0614;

public class Printer {
	
	int a = 10;
	
	static void Printer(int a) {
		System.out.println(a);
	}
	
	static void Printer(boolean a) {
		System.out.println(a);
	}
	
	static void println(double a) {
		System.out.println(a);
	}
	
	static void println(String a) {
		System.out.println(a);
	}
	
}
