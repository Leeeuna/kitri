package test0614;

public class PrinterExample {
	public static void main(String[] arg) {


		Printer.println(10);
		Printer.Printer(true);
		Printer.println(5.7);
		Printer.println("ȫ�浿");
//		System.out.println(Printer.a);
	}
//	public static void println(int a) {
//		System.out.println(a);
//	}
}
