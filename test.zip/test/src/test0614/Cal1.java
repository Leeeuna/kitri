package test0614;

public class Cal1 {
	int add(int a, int b) {
		return a+ b;
	}
	
	int add(int a, int b, int c) {
		return a+ b;
	}
	
	double add(double a, double b) {
		return a + b;
	}
	
	double add(double a, double b, double c) {
		return a + b;
	}
	
	int div(int a, int b) {
		return a/b;
	}
	
	int div(int a, int b,int c) {
		return a/b;
	}
	
	
	double div(double a, double b) {
		return a/b;
	}
	
	Cal1(){
		
	}
	
	Cal1(int a, int b){
		
	}
	
}
