package ioFile;

import java.io.*;

public class FileReaderWriterEx {
	public static void main(String[] args) {
		
		String path = "C:/Temp/foo2.txt";
		String path2 = "C:/Temp/foo/foo4.txt";
		
		
		
		try {
			FileReader fr = new FileReader(path);
			FileWriter fw = new FileWriter(path2);
			
			
			char[] buf = new char[10];
			int size = 0;
			while((fr.read(buf))!= -1){
				String data = new String(buf,0,size);
				fw.write(buf);
			}
			fw.flush();
			fw.close();
			fr.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
		
}
