package ioFile;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileStreamEx {
	public static void main(String[] args) {
		
		String path = "C:/Temp/foo2.txt";
		String path2 = "C:/Temp/foo3.txt";
		try {
			FileInputStream fis = new FileInputStream(path);
			FileOutputStream fos = new FileOutputStream(path2);
			
			int data;
			while((data = fis.read())!= -1){
				System.out.println(data + " ");
				fos.write(data);
			}
			
			fos.flush();
			fos.close();
			fis.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
