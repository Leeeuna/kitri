package ioFile;

import java.io.IOException;
import java.io.InputStream;

public class SystemInExample {
	public static void main(String[] args) {
		byte[] data = new byte[10];
		System.out.print("�Է� : ");
		
		InputStream is = System.in;
		try {
			int size = is.read(data);
			String datas = new String(data);
			System.out.println(datas);
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
