package ioFile;

import java.io.*;

public class FileEx {
	public static void main(String[] args) {
		File dir = new File("C:/Temp/foo");
		File file1 = new File("C:/Temp/foo2.txt");
		File file2 = new File("C:/Temp/foo.txt");
		
		try {
			file1.createNewFile();
			file2.delete();
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}
}	
