package collection;

import java.util.*;

public class TreesetEx {
	public static void main(String[] args) {
		TreeSet<Integer> score = new TreeSet<>();
		score.add(80);
		score.add(70);
		score.add(100);
		score.add(80);
		
		//�ڵ����� ���ĵȴ�
		int s = score.first();
		System.out.println(s);
		
		int l = score.last();
		System.out.println(l);
	
		s = score.lower(95);
		System.out.println(s);
	
		s = score.higher(95);
		System.out.println(s);
	}
}
