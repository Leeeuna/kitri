package collection;

import java.util.*;

public class ArrayListEx {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("JAVA");
		list.add("JDBC");
		list.add("Collection");
		list.add("euna");
		list.add(2,"loop");
		
		
		List<String> stooges = Arrays.asList("Larry", "mos","curly");
		Printlist(stooges);
		//Printlist(list);
		
		list.remove(2);
		//Printlist(list);
		
		list.clear();
		Printlist(list);
		
		System.out.println(list.isEmpty());
	}

	private static void Printlist(List<String> list) {
		for(int i =0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
}
