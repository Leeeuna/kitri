package test0613;

public class Car {
	String master;
	String model = "Sonata";
	int speed;
	int cc;
	int maxspeed;
	
	Car(String master){
		this.master = master;
		this.cc = 2000;
		this.maxspeed = 200;
	}
	Car(String master,int cc){
		this.master = master;
		this.cc = 2000;
		
	}
	
	void run() {
		speed = speed + 10;
	}

	void speedCheck(){
		System.out.println(speed);
	}
}
