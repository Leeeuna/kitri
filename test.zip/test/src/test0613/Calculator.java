package test0613;

public class Calculator {
	
	Calculator(){
		System.out.println("���Ⱑ ����� �����ϴ�.");
	}
	
	int add(int a, int b) {
		return a+b;
	}
	
	int minus(int a, int b) {
		return a-b;
	}
	
	int mux(int a, int b) {
		return a*b;
	}
	
	int div(int a, int b) {
		return a/b;
	}
}
