package test0613;

public class TrEx {
	public static void main(String[] arg) {
		//�ν��Ͻ�ȭ
		Tr tr = new Tr();
		Tr tr2 = new Tr();
		Tr tr3 = new Tr();
		Tr tr4 = new Tr();
		Tr tr5 = new Tr();
		Tr tr6 = new Tr();
		Tr tr7 = new Tr();
		
		tr.attack();
	}
}
