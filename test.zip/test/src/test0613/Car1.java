package test0613;

public class Car1 {
	String company = "�����ڵ���";
	String model;
	String color;
	int maxSpeed;
	
	Car1(){
		
	}
	
	Car1(String model){
		this(model,"����",250);
	}
	
	Car1(String model, String color){
		this(model, color, 250);
	}
	
	Car1(String model, String color, int maxSpeed){
		this.model = model;
		this.color = color;
		this.maxSpeed = maxSpeed;
	}
	
}
