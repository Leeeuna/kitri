package test0613;

public class TV {
	String made;
	int size;
	int price;
	boolean on;
	int vo;
	int ch;
	
	TV(String made){
		this.made = made;
		on = false;
		size = 65;
		price = 10000;
		vo = 0;
	}
	
	void on() {
		this.on = true;
		System.out.println("�������ϴ�.");
	}
	void off() {
		this.on = false;
		System.out.println("�������ϴ�.");
		
	}
	
	void voup() {
		if(on) {
		this.vo++;
		System.out.println(this.vo);
		}
	}
	
	void vodown() {
		if(on) {
			if(vo > 0) {
			this.vo--;
			System.out.println(this.vo);
			}else {
			System.out.println("���� 0");
			}
		}
	}
	
	void channel(int ch) {
		if(on) {
			this.ch = ch;
			System.out.println("���� ä�� : " + this.ch);
		}
	}

}
