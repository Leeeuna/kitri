package test0613;

public class CarEx {
	public static void main(String[] arg) {
		Car asurada = new Car("yeo");
		System.out.println(asurada.master);
	}
}
