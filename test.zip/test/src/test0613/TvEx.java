package test0613;

public class TvEx {
	public static void main(String[] arg) {
		TV samsung = new TV("samsung");
		
		
		TV LG = new TV("LG");

		
		samsung.on();
		samsung.voup();
		samsung.channel(50);
	}
}
