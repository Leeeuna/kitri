package test0613;

public class Memberservice {
	
	String id;
	String password;

	Memberservice(){
		id = "hong";
		password = "12345";
	}
	
	boolean login(String id, String password) {
		boolean result = false;
			if((this.id.equals(id))&&(this.password.equals(password))) {
				result = true;
			}
		return true;
		
	}
	void logout(String id) {
		
	}
	
}
