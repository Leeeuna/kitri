package test0613;

public class method {
	public static void main(String[] arg) {
		int a,b;
		int result,result2;
		
		a=10;
		b=20;
		
		result = a+b;
		result = add(a,b);
		
		int[] arr = {1,2,3};
		int[] arr2 = new int[3];
		
	
		myArrayCopy(arr,0,arr2,0,3);
		
		for(int value: arr2) {
			System.out.print(value + " ");
		}
		
		
	}
	
	public static void myArrayCopy(int[] arr,int a, int[] arr2, int b, int length) {
		for(int i =0; i<length; i++) {
			arr2[b++] =arr[a++];
			
		}
		return ;
	}
	
	
	public static int add(int a,int b) {
		int result;
		return result= a+b;
	}
	public static int minus(int a,int b) {
		int result;
		return result= a-b;
	}
	public static int mux(int a,int b) {
		int result;
		return result= a*b;
	}
	public static int div(int a,int b) {
		int result;
		return result= a/b;
	}
}
