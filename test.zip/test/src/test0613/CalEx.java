package test0613;

public class CalEx {
	public static void main(String[] arg) {
		Calculator cal = new Calculator();
		System.out.println(cal.add(10,20));
		System.out.println(cal.minus(10,20));
		System.out.println(cal.mux(10,20));
		System.out.println(cal.div(10,20));
	}
	
}
