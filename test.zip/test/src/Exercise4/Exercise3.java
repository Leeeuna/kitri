package Exercise4;

public class Exercise3 {
	public static void main(String[] arg) {
		int[] answer = {1,4,4,3,1,4,4,2,1,3,2};
		int[] counter = new int[4];
		for(int i =0; i < answer.length; i++) {
			while(answer[i] == 1) {
				counter[0]++;
				
				break;
			}
			while(answer[i] == 2) {
				counter[1]++;
				break;
			}
			while(answer[i] == 3) {
				counter[2]++;
				break;
			}
			while(answer[i] == 4) {
				counter[3]++;
				break;
			}
			
		}
		
		for(int i = 0; i < counter.length; i++) {
			
			System.out.print(counter[i] );
			System.out.println();
		}
	}
}
