package Exercise4;

public class Exercise2 {
	public static void main(String[] arg) {
		int [][] arr = {
				{5,5,5,5,5},
				{10,10,10,10,10},
				{20,20,20,20,20},
				{30,30,30,30,30}
				};
		int total = 0;
		float average =0;
		
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 5; j++) {
				total = total + arr[i][j];
				average = (float)total/20;
			}
		}
		
		System.out.println("total = "+ total);
		System.out.println("average = "+ average);
	}
}
