package Exercise4;

public class Exercise5 {
	public static void main(String[] arg) {
		int[] ballArr = {1,2,3,4,5,6,7,8,9};
		int[] ball3 = new int[3];
		
		for(int i =0; i < ballArr.length;i++) {
			int j = (int)(Math.random() * ballArr.length);
			int tmp =0;
			tmp = ballArr[j];
			ballArr[j] = ballArr[i];
			for(j = 0; j < 3; j++) {
				if(ballArr[j] ==  ballArr[j+1]) {
					
				}
			}
			
		}
		
		System.arraycopy(ballArr, 0, ball3, 0, 3);
		
		for(int i =0; i<ball3.length; i++) {
			System.out.println(ball3[i]);
		}
		
	}
}
