package Exercise4;

public class Exercise4 {
	public static void main(String[] arg) {
		int[][] score = {
				{100,100,100},
				{20,20,20},
				{30,30,30},
				{40,40,40},
				{50,50,50}
		};
		
		int[][] result = new int[score.length+1][score[0].length+1];
		
		for(int i=0; i<score.length; i++) {
			for(int j=0; j<score.length; j++) {
				System.arraycopy(score, 0, result, 0, score.length);
				result[5][j] = score[i][0] + score[i][1] + score[i][2];
				result[i][3] = score[0][j] + score[1][j] + score[2][j];
				result[5][3] = result[5][0] + result[5][1]+ result[5][2];
			}
		}
		
		for(int i=0; i<result.length; i++) {
			for(int j=0; j<result.length; j++) {
				System.out.printf("%4d", result[i][j]);
			}
			System.out.println();
		}
	}
}
