package test0619;

public class NullPointerExceptionEx {
	   public static void main(String[] args) {
	      try {

	         char[] ch = new char[5];
	         System.out.println(ch[4]);// ArrayIndexOutofBoundsException

	         String data = "data"; // NullPointerException
	         System.out.println(data.toString());
	         
	         String data1 = "100";
	         String data2 = "a100"; //NumberFormatException

	         int value1 = Integer.parseInt(data1);
	         int value2 = Integer.parseInt(data2);

	      } catch (ArrayIndexOutOfBoundsException | NullPointerException e) {
	         System.out.println("ArrayIndexOutOfBoundsException �߻� Ȥ��");
	         System.out.println("NullPointerException �߻�");
	         e.printStackTrace();
	         
	      } catch (Exception e) {   
	         System.out.println("Exception �߻�");
	      } finally {
	         System.out.println("Exception Ȯ�� ����");
	      }

	      

	      Dog dog = new Dog();
	      Cat cat = new Cat();
	      Animal animal = dog;
	      dog = (Dog) animal;
	      changeDog(animal);
	   }

	   public static void changeDog(Animal animal) {
	      Dog dog = (Dog) animal;
	   }

	}

	class Animal {
	}

	class Dog extends Animal {
	}

	class Cat extends Animal {
	}