package bb;

public class CC {
	int valueC = 3;
	
}
