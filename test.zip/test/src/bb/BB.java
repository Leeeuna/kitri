package bb;

public class BB {
	public static
	int valueB =2;
	
	void methodBB() {
		CC cc = new CC();
		cc.setValue(3);
	}
}

class CC{
	private int valueC =2;
	
//	private CC() {
//	
//	}
	
	public void setValue(int value) {
		valueC = value;
	}
}