package test;

public class IfElseIf {
	public static void main(String[] avg) {
		int height = 1880;
		
		if(height > 190) {
			System.out.println("XXL");
		}else if(height > 180) {
			System.out.println("XL");
		}else if(height > 170) {
			System.out.println("L");
		}
		

		
		
		
	}
}
