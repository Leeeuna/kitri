package test0618abstract;

public class StarCraft {

	public static void main(String[] args) {
		Tank tank = new Tank();
		Marine marine = new Marine();
		Dropship dropship = new Dropship();
		
		tank.stop();
		marine.stop();
		dropship.stop();
	}
}
