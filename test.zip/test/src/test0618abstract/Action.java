package test0618abstract;

public interface Action {
	void work();
}
