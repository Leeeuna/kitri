package test0618abstract;

public class Dog implements Soundable {
	public String sound() {
		return "�۸�";
	}
}
