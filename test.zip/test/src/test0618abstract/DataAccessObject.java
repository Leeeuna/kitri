package test0618abstract;

public interface DataAccessObject {
	public abstract void select();
	public abstract void insert();
	public abstract void update();
	public abstract void delete();
}
