package test0618abstract;

public class Cat implements Soundable {
	public String sound() {
		return "�߿�";
	}
}
