package test0618abstract;

public class ClassA implements A,B,C{

	@Override
	public void methodC() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		System.out.println("A-methodA");
	}
	
}
