package test0618abstract;

public class PhoneEx {
	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone("ȫ�浿");
		
		sp.turnOn();
		sp.internetSearch();
		sp.turnOff();
		sp.sound();
	}
}
