package test0618abstract;

public interface A {
	public void methodA();
}

interface B{
	public void methodB();
}

interface C{
	public void methodC();
}
