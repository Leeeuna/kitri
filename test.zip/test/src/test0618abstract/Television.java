package test0618abstract;

public class Television implements RemoteControl {
	private int volume;
	
	public void turnOn() {
		System.out.println("TvŴ");
	}
	public void turnOff() {
		System.out.println("Tv��");
	}
	
	public void setVolume(int volume) {
		if(volume >= RemoteControl.MAX_VOLUME) {
			System.out.println("���� �ִ뺼��");
		}else if(volume <= RemoteControl.MIN_VOLUME) {
			System.out.println("���� �ּҺ���");
		}else {
		this.volume = volume;
		}
	}
	@Override
	public int getVolume() {
		// TODO Auto-generated method stub
		return 0;
	}
}