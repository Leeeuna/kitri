package test0618abstract;

public class RemoteEx {
	public static void main(String[] args) {
//		RemoteControl rc = new Audio();
//		rc.turnOn();
//		rc.turnOff();
//		System.out.println(rc.getVolume());
//		rc.setVolume(10);
//		System.out.println(rc.getVolume());
//		
//		RemoteControl.changeBattery();
		
		RemoteControl rc = new RemoteControl(){
			public void turnOn() {};
			public void turnOff() {};
			public void setVolume(int volume) {}
			public int getVolume() {return 0;}
		};
		
	}
}
