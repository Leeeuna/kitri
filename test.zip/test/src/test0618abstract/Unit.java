package test0618abstract;

public abstract class Unit {
	int x,y;
	int hp = 100;
	void move(int x,int y) {
	}
	public abstract void stop();
	
}
		
class Marine extends Unit{
	int attacklevel;
	boolean mode;
	
	Marine(){
		hp = 100;
		attacklevel = 10;
		mode = false;
	}
	
	void attack(Unit enemy) {
		if(mode == true) {
		enemy.hp -= (attacklevel + 5);
		}else {
			enemy.hp -= (attacklevel);
		}
	}
	
	void stimPack() {
		mode = true;
		hp -= 10;
	}
	public void stop() {
		System.out.println("Marine");
	}
}

class Tank extends Unit{
	void changeMode() {
	}
	public void stop() {
		System.out.println("Tank");
	}
}

class Dropship extends Unit{
	void load() {
	}
	
	void unload() {
	}
	public void stop() {
		System.out.println("Dropship");
	}
}
