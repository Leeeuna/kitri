package test0618abstract;

public class Node {
	int num;
	Node front;
	Node back;
	Node tmp;
}
	

class NodeEx{
	
	public static void main(String[] args) {
		Node node1 = new Node();
		Node node2 = new Node();
		Node node3 = new Node();
		
		node1.num =2;
		node2.num =3;
		node3.num =4;
		
		Node tmp = new Node();
		
		node1.back = node2;
		node2.back = node3;
		
		node2.front = node1;
		node3.front = node2;
		
		tmp.back = node3;
		tmp.front = node2;
		node2.back = tmp;
		node3.front =tmp;
		
		//node1 node2 tmp���� node3
		node1.back = node2;
		node2.back = node3;
		node2.front = node1;
		node3.front = node2;
		tmp = null;
		
		//node1 node2 node3
		int size = 0;
		Node index = node1;
		size++;
		
		while(true) {
			if(index.back != null) {
				size++;
				index = index.back;
			}else {
				break;
			}
		}
		System.out.println(size);
		index = node1;
		for(int i = 0; i<(size-1);i++) {
			index= index.back;
		}
	}
	
}

