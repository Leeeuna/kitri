package test0618abstract;

public interface Soundable {
	String sound();
}
