package test0618abstract;

public class Laptop implements Blutooth, USB, LanCard {
	public static void main(String[] args) {
		Laptop laptop = new Laptop();
		Blutooth blutooth = laptop;
		System.out.println(blutooth.getMaker());
		System.out.println(blutooth.getVersion());
		System.out.println(blutooth.getCapability());
	}
	
	public String getMaker() {
		return maker;
	}
	
	public double getVersion() {
		return version;
	}
	
	public String getCapability() {
		return capa;
	}
}


interface Blutooth{
	String maker = "samsung";
	double version = 3.0;
	String capa = "128GB";
	
	public abstract String getMaker();
	public abstract double getVersion();
	public abstract String getCapability();
}

interface USB{
	
}

interface LanCard{
	
}