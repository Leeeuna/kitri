package generic;

public class BoxEx {
	public static void main(String[] args) {
		Box<String> box1 = new Box<String>();
		box1.set("hello");
		String str = box1.get();
		
		Box2 box2 = new Box2();
		box2.set("Hello");
		box2.set(123454);
		
		Box<Integer> box3 = new Box<>();
		box3.set(6);
		int value = box3.get();
	}
}

