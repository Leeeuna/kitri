package generic;

public class Box<T> {//T <= String
	private T t;
	public T get() {return t;}
	public void set(T t) {this.t = t;}
	
	
	public static <T> Box<T> boxing(T t) {
		Box<String> box = new Box<>();
		return (Box<T>) box;
	}
	
	
	
	
	
	
	
	
	
}

class Box2 {//T <= String
	private Object t;
	public Object get() {return t;}
	public void set(Object t) {this.t = t;}
}

interface Box3<T>{
	static int a = 0;
	public T get();
	public void set(T t);
}