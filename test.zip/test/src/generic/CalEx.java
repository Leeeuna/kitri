package generic;

public class CalEx {

}
