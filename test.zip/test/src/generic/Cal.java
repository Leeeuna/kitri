package generic;

public class Cal {
	int plus(int x, int y) {
		return x+y;
	}
	
	double plus(double x, double y) {
		return x+y;
	}
	
	
}
