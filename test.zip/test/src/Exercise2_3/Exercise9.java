package Exercise2_3;

public class Exercise9 {
	public static void main(String[] arg) {
		int number = 12321;
		int tmp = number;
		int result = 0;
		
		while(tmp != 0) {
			result = result *10 + tmp % 10;
			tmp /= 10;
		}
		
		if(number == result)
			System.out.println(number + "�� ȸ���� �Դϴ�.");
		else
			System.out.println(number + "�� ȸ������ �ƴմϴ�.");
	}
}
