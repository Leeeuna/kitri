package Exercise2_3;

public class Exercise1 {
	public static void main(String[] args) {
		int fahrenheit=100;
		float celcius=  (fahrenheit - 32) * (5.0f/9.0f);
		System.out.println("Fahrenheit : " + fahrenheit);
		System.out.println("Celcius : " + Math.round(celcius*100)/100.0);
	}
}
