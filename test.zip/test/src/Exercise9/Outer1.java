package Exercise9;

public class Outer1 {
	static class Inner{
		int iv = 200;
	}
}

class Exercise3{
	public static void main(String[] args) {
		
	}
}
