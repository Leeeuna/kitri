package Exercise9;

public class Outer {
	class Inner{
		int iv = 100;
	}
}

class Exercise2{
	public static void main(String[] args) {
		System.out.println();
	}
}
