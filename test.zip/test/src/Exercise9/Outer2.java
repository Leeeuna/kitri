package Exercise9;

public class Outer2 {
	int value = 10;
	
	class Inner{
		int value = 20;
		void method1() {
			int value = 30;
			System.out.println();
			System.out.println();
			System.out.println();
		}
	}
}

class Exercise4{
	public static void main(String[] args) {
		
		
		inner.method1();
	}
}