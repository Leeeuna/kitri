package referencetype;

public class array {
	public static void main(String[] arg) {
		int[] num= {10,20,30};
		int temp;
		for(int i=0; i<3; i++) {
			for(int j=i+1; j<3; j++) {
				if(num[i]< num[j]) {
					temp = num[j];
					num[j]=num[i];
					num[i]=temp;
				}
				
			}
			System.out.println(num[i]);
		}
		
	}
}
