package referencetype;

import java.util.Scanner;

public class scannerex {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String inputString = scanner.nextLine();
		
		System.out.println(">>"+inputString);
	}
}
