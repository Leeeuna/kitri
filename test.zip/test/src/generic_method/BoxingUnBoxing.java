package generic_method;

public class BoxingUnBoxing {
	public static void main(String[] args) {
		int a = 10;
		Integer obj1 = new Integer(10);
		Integer obj2 = 10;
		
		System.out.println(a);
		System.out.println(obj1);
		System.out.println(obj2);
		
		double b = (double)a;
		double c = obj2.doubleValue() + 10.0;
		System.out.println(c);
		
		int max = obj1.MAX_VALUE;
		System.out.println(max);
		
		Integer num = new Integer("12345");
		System.out.println(num);
		//Integer num = "12345";
		int num2 = obj1.valueOf("12345");
		System.out.println(num2);
		
	}
}
