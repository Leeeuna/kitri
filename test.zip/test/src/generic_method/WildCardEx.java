package generic_method;

public class WildCardEx {
	public static void regCourse(Course<?> course) {
		
	}
	
	public static void regCourseStudent(Course<? extends Student> course) {
		
	}
	
	public static void regCourseWorker(Course<? super Worker> course) {
		
	}
	
	public static void main(String[] args) {
		regCourse(new Course<Person>());
		regCourse(new Course<Student>());
		regCourse(new Course<Person>());
		regCourse(new Course<Worker>());
		
		regCourseStudent(new Course<Student>());
	//	regCourseStudent(new Course<Person>());//error
	//	regCourseStudent(new Course<Worker>());//error
		regCourseStudent(new Course<HighStudent>());
		
		regCourseWorker(new Course<Person>());
		regCourseWorker(new Course<Worker>());
	//	regCourseWorker(new Course<Student>());//error
	//	regCourseWorker(new Course<HighStudent>());//error
	}
}

class Course<T>{}

class Person{}
class Worker extends Person{}
class Student extends Person{}
class HighStudent extends Student{}
