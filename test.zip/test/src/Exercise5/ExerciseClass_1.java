package Exercise5;

public class ExerciseClass_1 {
	public static void main(String args[]) {
		int[] data = {3,2,9,4,7};
		System.out.println(java.util.Arrays.toString(data));
		System.out.println("�ִ밪 : "+ max(data));
		System.out.println("�ִ밪 : "+ max(null));
		System.out.println("�ִ밪 : "+ max(new int[] {}));
		int value =5;
		System.out.println(value+ "�� ���밪 : " +abs(value));
		value = -10;
		System.out.println(value+ "�� ���밪 : " +abs(value));
		
		
	}

	static int abs(int value) {
		int abs = Math.abs(value);
		return abs;
	}

	static int max(int[] arr) {
		int max = 0;
		int i = 0;
		if(arr != null){
			while(i < arr.length) {
				max = arr[0];
				if(arr[i]> max) {
					max = arr[i];
				}
				i++;
			}	
		}if(arr == null || arr.length == 0) {
			return -999999;
		}
		return max;
	}
}
