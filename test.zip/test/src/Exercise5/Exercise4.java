package Exercise5;

public class Exercise4 {
	
	static boolean isNumber(String str) {
		try {
			int num = Integer.parseInt(str);
			return true;
		}catch(Exception e) {
			return false;
		}	
	}
	
	public static void main(String[] args) {
		String str = "123";
		System.out.println(str + "�� �����Դϱ�?" + isNumber(str));
		str = "1234��";
		System.out.println(str + "�� �����Դϱ�?" + isNumber(str));
	}
}
