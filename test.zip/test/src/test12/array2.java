package test12;

public class array2 {
	public static void main(String[] args) {
		int arr[][]  = new int[5][5];
		int sum =1;
		for(int i=0; i<arr.length; i++) { 
			if(i%2 == 0) {
				for(int j=0; j<arr.length; j++) {
		
					arr[i][j] = sum;
					sum = sum+1;
				
				}
			}else {
				for(int j=4; j>=0; j--) {
					arr[i][j] = sum;
					sum = sum+1;
				}
			}
		}
					
			for (int i = 0; i < arr.length; i++) {
		         for (int j = 0; j < arr.length; j++) {
		            System.out.print(arr[i][j] + " ");
		         }
		         System.out.println();
		      }
	
			
	
			
		}
		
	
}