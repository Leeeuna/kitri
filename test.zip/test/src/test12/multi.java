package test12;

public class multi {
	public static void main(String[] args) {
//		int[][] arr = {{10,20,30},{40,50,60}};
//		
//		for(int i=0;i<2;i++) {
//			for(int j=0;j<3;j++) {
//				System.out.print(arr[i][j]);
//			}
//			System.out.println();
//		}
		
		
		int [][]multi = new int[9][3];

		for(int i=0; i<multi.length; i++) {
			multi[i][0] = 9; 
			multi[i][1] = i;
			multi[i][2] = multi[i][0] * multi[i][1];
		}
		for(int i=0; i<multi.length; i++) {
			System.out.println(multi[i][0] + " " + multi[i][1] + " "+ multi[i][2]);
		}
	}
}
