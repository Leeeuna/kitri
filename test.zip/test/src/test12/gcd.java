package test12;

public class gcd {
	public static void main(String[] args) {
		int a = 10;
		int b = 15;
		int g=0;
		int h =0;
//		int big, small, g,l,m,n;
//		if(a>=b) {
//			big = a;
//			small =b;
//		}else {
//			small =a;
//			big = b;
//		}
//		while(true) {
//			m = big/small;
//			n=big-m*small;
//			if(n==0) {
//				g = small;
//				l = (a*b) / g;
//				System.out.println(g + " " + l);
//			}
//			big = small;
//			small = n;
		int max =(a>b) ? a : b;
		for(int i =2; i<=max; i++) {
			if((a%i ==0) && (b%i ==0))
				g = i;
		}
		System.out.println(g);
		
		for(int i = max; i < 10000; i++) {
			if((i%a ==0) &(i%b==0)) {
				h = i;
				break;
			}
		}
		System.out.println(h);

		int y = a*b/g;
		System.out.println(y);
			}
}
