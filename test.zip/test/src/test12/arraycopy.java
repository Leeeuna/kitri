package test12;

public class arraycopy {
	public static void main(String[] args) {
		String[] oldstrarr = {"Java","Copy"};
		String[] newstrarr = new String[5];
		
//		for(int i=0; i<oldstrarr.length; i++) {
//			newstrarr[i] = oldstrarr[i];
//		}
		System.arraycopy(oldstrarr, 0, newstrarr, 1, 1);
		for(int i=0; i<newstrarr.length; i++) {
			System.out.println(newstrarr[i]);
		}
		System.out.println();
		for(int i=0; i<oldstrarr.length; i++) {
			System.out.println(oldstrarr[i]);
		}
	}
}
