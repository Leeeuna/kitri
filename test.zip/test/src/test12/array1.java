package test12;

public class array1 {
	public static void main(String[] args) {
		int[] array = {20,17,6,8,40,39};
		int temp = 0;
		double avg = 0;
		for(int i = 0; i < array.length; i++) {
			for(int j = i + 1; j  <array.length; j++) {
				if(array[i]>array[j]) {
					temp = array[j];
					array[j] = array[i];
					array[i] = temp;
					
					avg = (array[array.length-1]+array[array.length-2]+array[array.length-3])/3.0;
				}
				
			}	
		}
		
		System.out.println(avg);
//		for(int i = 0; i < array.length; i++) {
//			System.out.print(array[i] + " ");
//		}
	}
}
