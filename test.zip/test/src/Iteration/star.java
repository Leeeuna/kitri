package Iteration;

public class star {
		public static void main(String[] args) {
			for(int i = 0; i<5; i++) {
				for(int j =1; j<(5-i);j++) {
					if(j <i)
						
					System.out.print("*");
				}
				
			System.out.print("\n");
			}
		}
}
