package Iteration;

public class ForWhile {
	public static void main(String[] args) {
/*		//�ʱⰪ ���� ����
//		
//		for(int i = 1; i <=100; i++) {
//			System.out.print(i+" ");
//			if(i%10==0) {
//				System.out.print("\n");
//			}
//		}
*/		
		
		
		for(int j=2; j <=100; j++) {
			for(int k = 2; k<=j; k++) {
					if(j !=k && j % k == 0) break;
					if(j==k) {
						
					System.out.print(j +" ");
					
					}
			}
			
		}
	}
}
