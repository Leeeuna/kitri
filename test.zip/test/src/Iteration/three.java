package Iteration;

public class three {
	public static void main(String[] args) {
//		int sum = 0;
//		for(int i=1; i<=100; i++) {
//			if(i%3 == 0) {
//				sum = sum + i;
//			}
//		}
//		System.out.println(sum);
		int i=0;
		int sum = 0;
		do {
			if(i%3 ==0) {
				sum +=i;
			}
			i++;
			
			}while(i<=100);
		System.out.println(sum);
		
	}
	
}
