package Iteration;

public class gugudan {
	public static void main(String[] args) {
		   for (int i =1 ; i<10; i++){
			   for(int j =2 ; j<10; j++){
				   if(i == j-1) 
						System.out.print( "        ");
				   else
				   System.out.print(j + "X" + i  + "=" + i*j  +"\t");
		      
			   }
		   System.out.print("\n");
		   }
	}
}
