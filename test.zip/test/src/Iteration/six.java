package Iteration;

public class six {
	public static void main(String[] args) {
		for(int i=0;i<=4;i++)
        {
           for(int j=1;j<(4-i);j++)
           {
        	 System.out.print("^");
        	}
           for(int j =0; j< i+1; j++) {
              System.out.print("*");
        	  
           }
           System.out.println();
        }
		for(int k = 0; k<3; k++) {
			for(int l =1; l<(4-k);l++) {
				
				
					
				System.out.print("*");
			}
			
		System.out.print("\n");
		}
	}
}
