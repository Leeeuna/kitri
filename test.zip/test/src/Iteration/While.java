package Iteration;

public class While {
	public static void main(String[] args) {
		while(true) {
			System.out.println("*");
			break;
		}
		for(;(true);) {
			System.out.println("%");
			break;
		}
	}
}
