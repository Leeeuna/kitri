package dataClass;

public class Order {
	
	private long orderNum;		// �ֹ���ȣ
	private int itemNum;			// ��ǰ��ȣ
	private String itemName;		// ��ǰ�̸�
	private String category;		// ī�װ���
	private int price;				// ����
	private int isTakeout;			// ����0/����ũ�ƿ�1
	private String cupSize;			// ������
	private String options;			// �µ�/�絵/������
	private String orderDate;		// �ֹ���¥
	private boolean isComplete;		// �ֹ��Ϸ� ����
	private int count;				// ����
	
	// getter setter
	public long getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(long orderNum) {
		this.orderNum = orderNum;
	}
	public int getItemNum() {
		return itemNum;
	}
	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}
	public int getIsTakeout() {
		return isTakeout;
	}
	public void setIsTakeout(int isTakeout) {
		this.isTakeout = isTakeout;
	}
	public String getCupSize() {
		return cupSize;
	}
	public void setCupSize(String cupSize) {
		this.cupSize = cupSize;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public boolean getIsComplete() {
		return isComplete;
	}
	public void setIsComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}

