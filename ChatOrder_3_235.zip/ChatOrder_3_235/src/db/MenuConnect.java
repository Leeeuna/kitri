package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dataClass.Menu;

public class MenuConnect {

	private static Connection conn;
	
	private PreparedStatement pstmt;
	private CallableStatement cstmt;
	private ResultSet rs;

	// �⺻ ������
	public MenuConnect() {
	      
	}

	// DB�� �����ϴ� �޼ҵ�
	private void getConnection() {
		
		if (conn == null) { // dbConn�� null�̸� Connection ��ü ������
			// ��������
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hyejin";
			String pw = "wow130";

			// JDBC����̹� �ε�
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println("����̹� �ε� ����");
				e.printStackTrace();
			}

			// ����Ŭ(DBMS)�� �����Ͽ� Connection ��ü ���.
			try {
				conn = DriverManager.getConnection(url, user, pw);
			} catch (SQLException e) {
				System.out.println("connection ����");
				e.printStackTrace();
			}
		}
	}

	// DB���� �ش� category�� �޴��� �ҷ����� �޼ҵ�
	public List<Menu> getMenuList(String category) {

		List<Menu> list = new ArrayList<Menu>();

		try {
			getConnection();

			String sql = "select * from menu where item_category = \'" + category + "\'";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				int ITEM_NUM = r.getInt("ITEM_NUM");
				String ITEM_NAME = r.getString("ITEM_NAME");
				r.getString("ITEM_CATEGORY");
				int ITEM_PRICE = r.getInt("ITEM_PRICE");
				int ITEM_TALL_PRICE = r.getInt("ITEM_TALL_PRICE");
				int ITEM_GRANDE_PRICE = r.getInt("ITEM_GRANDE_PRICE");

				list.add(new Menu(ITEM_NUM, ITEM_NAME, ITEM_PRICE, ITEM_TALL_PRICE, ITEM_GRANDE_PRICE));
			}

		} catch (Exception e) {
			System.out.println("���ܹ߻�:getMenuList()=> " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	private void dbClose() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("����:ResultSet��ü close():" + e.getMessage());
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("����:PreparedStatement��ü close():" + e.getMessage());
			}
		}

		if (cstmt != null) {
			try {
				cstmt.close();
			} catch (SQLException e) {
				System.out.println("����:CallableStatement��ü close():" + e.getMessage());
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("����:Connection��ü close():" + e.getMessage());
			}
		}

		conn = null;

	}
}