package com.studybb.service;

import java.util.List;

import com.studybb.dao.StudyDAO;
import com.studybb.exception.NotFoundException;
import com.studybb.vo.PageBean;
import com.studybb.vo.Study;

public class StudyService {
	private StudyDAO dao;
	
	public StudyService(){
		dao = new StudyDAO();
	}
		
	public PageBean<Study> search(String study_area, int study_type, String study_tag, int startRow) 
			throws NotFoundException {
		int cntPerPage = 9; // 한 페이지 별 보여줄 게시글 수
		int endRow = startRow + cntPerPage - 1;
		
		List<Study> list = dao.selectBySearch(study_area, study_type, study_tag, startRow, endRow);
		int totalCnt = 0;
		totalCnt = dao.count(study_area, study_type, study_tag);
		PageBean<Study> pb = new PageBean<>();
		pb.setCntPerPage(cntPerPage); // 페이지 별 목록수
		pb.setList(list); // 페이지 목록
		pb.setTotalCnt(totalCnt); // 총 건수

		return pb;
	}

	public PageBean<Study> search() throws NotFoundException {
		return search("전체", 2, "", 1);
	}
}
