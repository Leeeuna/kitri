package com.studybb.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.studybb.exception.NotFoundException;
import com.studybb.vo.Member;
import com.studybb.vo.Study;

public class StudyDAO {
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "STUDYBB";
	private String pw = "STUDYBB";
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	
	public List<Study> selectBySearch(String area, int type, String tag, int startRow, int endRow) 
			throws NotFoundException {

		List<Study> list = new ArrayList<Study>();
		try {
			// 1) JDBC 드라이버 로드
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2) DB 연결
			conn = DriverManager.getConnection(url, user, pw);
			System.out.println("connection 성공");

			// 3) SQL 구문 송신
			String selectSQL = "SELECT A.*, rno\r\n" + 
					"FROM (SELECT B.* , rownum AS rno\r\n" + 
					"      FROM (SELECT s.*, m.mem_name\r\n" + 
					"            FROM study s, member m\r\n" + 
					"            WHERE s.mem_id = m.mem_id\r\n";
			
			// if(전체가 아닐때)
			if(!"".equals(tag)) {
				selectSQL += "AND REGEXP_LIKE(study_tag, '" + tag + "') \r\n";
			}
			if(!"전체".equals(area)) {	 
				selectSQL += "AND study_area = '" + area + "' \r\n";
			} 
			if(type != 2) {
				selectSQL += "AND study_type = '" + type + "' \r\n";
			} 

			selectSQL += "ORDER BY STUDY_UPLOAD DESC) B) A\r\n" + 
					"WHERE rno BETWEEN ? AND ?";
			pstmt = conn.prepareStatement(selectSQL);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				//Member m = new Member();
				int study_no = rs.getInt("study_no");
				String study_title=rs.getString("study_title");
				int study_price = rs.getInt("study_price");
				int study_week = rs.getInt("study_week");
				Date study_due = rs.getDate("study_due");
				String mem_id = rs.getString("mem_id");
				String mem_name = rs.getString("mem_name");
				Date study_start = rs.getDate("study_start");
				Date study_upload = rs.getDate("study_upload");
				String study_area = rs.getString("study_area");
				String study_tag = rs.getString("study_tag");
				int study_type = rs.getInt("study_type");
				Member mem = new Member();
				mem.setMem_id(mem_id);
				mem.setMem_name(mem_name);
				
				Study study = new Study(study_no, mem, "", study_title, study_area, study_start, study_week,
				         study_due, "", study_tag, study_upload, study_type, study_price, 1);
				// 대입
				list.add(study);
			}
			if(list.size() == 0) {
				throw new NotFoundException("검색결과가 없습니다.");
			}
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
		return list;
		
	}
	
	public void closeConnection() {
		// 5) 연결 닫기
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int count(String study_area, int study_type, String study_tag) throws NotFoundException {
		try {
			// 1) JDBC 드라이버 로드
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2) DB 연결
			conn = DriverManager.getConnection(url, user, pw);
			System.out.println("connection 성공");

			// 3) SQL 구문 송신
			String selectSQL = "SELECT count(*) \r\n" + 
					"           FROM study s, member m\r\n" + 
					"           WHERE s.mem_id = m.mem_id\r\n";
			
			// if(전체가 아닐때)
			if(!"".equals(study_tag)) {
				selectSQL += "AND REGEXP_LIKE(study_tag, '" + study_tag + "') \r\n";
			}
			if(!"전체".equals(study_area)) {	 
				selectSQL += "AND study_area = '" + study_area + "' \r\n";
			} 
			if(study_type != 2) {
				selectSQL += "AND study_type = '" + study_type + "' \r\n";
			}
			pstmt = conn.prepareStatement(selectSQL);

			// 4) SQL구문 실행
			rs = pstmt.executeQuery();

			// 5) 결과 확인
			// count는 테이블이 없을 경우 바로 exception을 날리기 때문에 rs.next()를 체크해줄 필요가 없다
			// 행이 없을 경우에는 0 반환
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			// 사용자 정의 Exception 강제 발생
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
	}
}
