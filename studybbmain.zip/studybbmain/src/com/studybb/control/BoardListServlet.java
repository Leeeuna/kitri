package com.studybb.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.studybb.exception.NotFoundException;
import com.studybb.service.BoardService;
import com.studybb.vo.Board;
import com.studybb.vo.PageBean;
import com.studybb.vo.Study;

@WebServlet("/boardlist")
public class BoardListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BoardService service;

	public BoardListServlet() {
		service = new BoardService();
	}

	// GET / POST 방식 가리지 않음
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String type = request.getParameter("type");
		String no = request.getParameter("no");
		String input = request.getParameter("input"); 
		int intNo = 1;
		if (no != null) {
			// NullPointException 회피
			System.out.println(no);
			intNo = Integer.parseInt(no);
		}

		try {
			PageBean<Board> pb = new PageBean<Board>();
			if(no == null && type == null && input == null) {
				pb = service.boardList();
			} else {
				pb = service.boardList(intNo, type, input);
			}
			request.setAttribute("pb", pb);
			request.setAttribute("status", 1); // 정상 처리
			request.setAttribute("type", type);
		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("status", -1); // 실패
		}
		
		String path = "";
		// 처음 페이지 로드
		if(no == null && input.equals("") && type.equals("recent")) {
			// jsp로 데이터를 넘겨주고 forward
			System.out.println("퍼스트~");
			path = "/boardlist.jsp";
		} else {
			// scroll append 페이지 로드
			System.out.println("아니야");
			path = "/boardresult.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);
	}
}
