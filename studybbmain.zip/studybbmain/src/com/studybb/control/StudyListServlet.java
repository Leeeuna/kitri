package com.studybb.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.studybb.exception.NotFoundException;
import com.studybb.service.StudyService;
import com.studybb.vo.PageBean;
import com.studybb.vo.Study;

@WebServlet("/studylist")
public class StudyListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudyService service;
	
    public StudyListServlet() {
    	service = new StudyService();
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("servlet");
		String area = request.getParameter("area");
		String type = request.getParameter("type");
		String tag = request.getParameter("tag");
		String no = request.getParameter("no");
		int intNo = 1;
		int intType = 2;
		
		if(no != null) {
			intNo = Integer.parseInt(no);
		}
		if(type != null) {
			intType = Integer.parseInt(type);
		}
		
		try {
			PageBean<Study> pb = new PageBean<Study>();
			if(area == null && type == null && tag == null && no == null) {
				pb = service.search();
			} else {
				pb = service.search(area, intType, tag, intNo);
			}
			request.setAttribute("pb", pb);
			request.setAttribute("status", 1); // 정상 처리
		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("status", -1); // 실패
		}
		
		String path = "";
		if(area == null && type == null && tag == null && no == null) {
			path = "/search.jsp";
		} else {
			path = "/searchresult.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);
	}

}
