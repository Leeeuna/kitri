package a;

public class Second1 implements Second{

	@Override
	public String info() {
		// TODO Auto-generated method stub
		return "Second1객체입니다.";
	}
	
}
