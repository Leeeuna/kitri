package a;

public class Second2 implements Second{

	@Override
	public String info() {
		// TODO Auto-generated method stub
		return "Second2객체입니다.";
	}

}
