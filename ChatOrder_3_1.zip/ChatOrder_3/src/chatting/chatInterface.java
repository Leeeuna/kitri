package chatting;

public interface chatInterface {
	
	static String getMessage(String str) {
		
		//
		return str;
	}
	

}
