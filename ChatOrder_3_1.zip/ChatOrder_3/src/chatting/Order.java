package chatting;

public class Order {

}
