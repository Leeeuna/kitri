package chatting;

public class Message {
	private static String message = null;
	
	public static String getMessage() {
		return message;
	}
	
	public static void setMessage(String str) {
		message = str;
	}

}
