package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.exception.NotFoundException;
import com.my.service.BoardService;
import com.my.vo.Board;
import com.my.vo.PageBean;

public class BoardController {
	private BoardService service;
//	public BoardController() {
//		service = new BoardService();
//	}
	
	static private BoardController controller = new BoardController();
	private BoardController() {
		service = new BoardService();
	}
	
	static public BoardController getInstance() {
		return controller;
	}
	
	public String boardList(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String currentPage = request.getParameter("currentPage");
		int intCurrentPage = 1;
		if(currentPage != null) {
			intCurrentPage = Integer.parseInt(currentPage);
		}
		try {
			PageBean<Board> pb = service.boardList(intCurrentPage);
			request.setAttribute("pb", pb);
			request.setAttribute("status", 1);
		} catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("status", -1);
		}	
		
		String path ="/boardlistresult.jsp";
		return path;
	}
	
	public String boardDetail(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String board_no = request.getParameter("board_no");
		int intBoardNo = 0;
		if(board_no != null) {
			intBoardNo = Integer.parseInt(board_no);
		}
		try {
			Board board = service.boardDetail(intBoardNo);
			request.setAttribute("board", board);
			request.setAttribute("status", 1);	
		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("status", -1);
		}
		String path = "/boarddetailresult.jsp";
		return path;
	}
	
	public String boardPwdChk(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String board_no = request.getParameter("board_no");
		String board_pwd = request.getParameter("board_pwd");
		int intBoardNo = 0;
		if(board_no != null) {
			intBoardNo = Integer.parseInt(board_no);
		}
		
		String str = service.boardPwdChk(intBoardNo, board_pwd);
		request.setAttribute("result", str);
			
		String path = "/result.jsp";
		return path;
	
	}
	
	public String boardReply(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String str_parent_no = request.getParameter("parent_no");
		int parent_no = Integer.parseInt(str_parent_no);
		String board_subject = request.getParameter("board_subject");
		String board_writer = request.getParameter("board_writer");
		String board_content = request.getParameter("board_content");
		String board_pwd = request.getParameter("board_pwd");
		
		Board board = new Board();
		board.setParent_no(parent_no);
		board.setBoard_subject(board_subject);
		board.setBoard_writer(board_writer);
		board.setBoard_content(board_content);
		board.setBoard_pwd(board_pwd);
		String result = service.boardReply(board);
		request.setAttribute("result", result);
		
		String path = "/result.jsp"; 
		return path;
	}
	
	public String boardWrite(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Board board = new Board();
		board.setBoard_subject(request.getParameter("board_subject"));
		board.setBoard_writer(request.getParameter("board_writer"));
		board.setBoard_pwd(request.getParameter("board_pwd"));
		board.setBoard_content(request.getParameter("board_content"));

		String str = service.boardWrite(board);
		request.setAttribute("result", str);
		String path = "/result.jsp";
		return path;		
	}
}
