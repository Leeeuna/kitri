package control;

public interface Controller {
	public abstract Controller getInstance();
	
}
