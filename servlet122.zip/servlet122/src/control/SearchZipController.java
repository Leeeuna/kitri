package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.exception.NotFoundException;
import com.my.service.ZipService;

public class SearchZipController {
	private ZipService service;
//	public BoardController() {
//		service = new BoardService();
//	}
	
	static private SearchZipController controller = new SearchZipController();
	private SearchZipController() {
		service = new ZipService();
	}
	
	static public SearchZipController getInstance() {
		return controller;
	}
	
	public String boardList(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String doro = request.getParameter("doro");
		String result = service.searchZip(doro);
		
		request.setAttribute("result", result);
		String path = "/result.jsp";
	
		return path;
	}
}