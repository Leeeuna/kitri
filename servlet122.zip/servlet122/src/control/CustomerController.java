package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.my.exception.NotFoundException;
import com.my.service.CustomerService;


public class CustomerController {
	private CustomerService service;

	
	static private CustomerController controller = new CustomerController();
	private CustomerController() {
		service = new CustomerService();
	}
	
	static public CustomerController getInstance() {
		return controller;
	}
	
	public String login(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("loginInfo");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String str = service.login(id, pwd);
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(str);
			JSONObject jsonObj = (JSONObject)obj;
			if((Long)jsonObj.get("status") ==1) {//로그인 성공된 케이스
				session.setAttribute("longinInfo", id);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("result", str);
		String path = "/result.jsp";
		return path;
	}
	
	public String join(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
	    String pwd = request.getParameter("pass");
	    String name = request.getParameter("name");
	    String addr = request.getParameter("addr2");
	    String buildingno = request.getParameter("buildingno");

	    
	    System.out.println(id+pwd+name+buildingno+ "/" +addr);
	    
		String str = service.join(id, pwd, name, buildingno, addr);
		request.setAttribute("result", str);
	    String path = "/result.jsp";
		return path;
	}
	
	public String dupchk(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");	
		CustomerService service = new CustomerService();
		String str = service.dupchk(id);
		request.setAttribute("result", str);
		String path = "/result.jsp";
		return path;
	}
	public String logout(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		return "-1";
	}
}
