package com.my.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.my.dao.BoardDAO;
import com.my.exception.NotFoundException;
import com.my.vo.Board;
import com.my.vo.Customer;
import com.my.vo.PageBean;

public class BoardService {
	private BoardDAO dao;
	public BoardService() {
		dao = new BoardDAO();
	}
	public com.my.vo.PageBean<Board>  boardList() throws NotFoundException{
		return boardList(1);
	}
	public com.my.vo.PageBean<Board> boardList(int currentPage) 
	                    throws NotFoundException{
		int cntPerPage = 3; //한페이지별 보여줄 목록수 
		int cntPerPageGroup = 4;//페이지그룹에서 보여줄 페이지수
		int startRow = ((currentPage-1) * cntPerPage)+1;
		int endRow = currentPage * cntPerPage;
		List<Board> list = dao.select(startRow, endRow);
		
		int totalCnt = dao.count();
		int maxPage = (int)(Math.ceil((float)totalCnt/cntPerPage));
		
		//페이지그룹의 시작페이지,끝페이지 계산
		int startPage = ((currentPage-1)/cntPerPageGroup)*cntPerPageGroup +1;
		int endPage = startPage + cntPerPageGroup -1;
		if(endPage > maxPage) {
			endPage= maxPage;
		}
		
		System.out.println(currentPage+"="+startPage + endPage);
		
		PageBean<Board> pb = 
				new PageBean<>();
		pb.setStartPage(startPage);
		pb.setEndPage(endPage);
		pb.setCurrentPage(currentPage);//현재페이지
		pb.setCntPerPage(cntPerPage);//페이지별 목록수
		pb.setList(list); //목록
		pb.setTotalCnt(totalCnt); //총건수
		pb.setMaxPage(maxPage);	//최대페이지수
		return pb;
	}	
	
	public Board boardDetail(int board_no) throws NotFoundException{
	
		try {
			Board board = dao.selectByBoardNo(board_no);
			Board b = new Board();
			for() {
				int board_no = b.get("board_no");
				int parent_no = b.get("parent_no");
				String board_subject = b.get("board_subject");
				String board_writer = b.get("board_writer");
				Date board_time = b.get("board_time");
				String board_content = b.get("board_content");
				JSONObject jsonObj = new JSONObject();
				jsonObj.putAll(b);
	
			}
		}catch(NotFoundException e) {
			e.printStackTrace();			
		}
		System.out.println(jsonArr.toJSONString());
		System.out.println(jsonArr.toString());
		return jsonObj.toString();
	}
	
	public String boardReply(Board board) {

		int status = -1;
		String msg = "답글쓰기 실패";
		try {
				dao.insert(board);
				status = 1;
			
		} catch (NotFoundException e) {
			msg+=e.getMessage();
			e.printStackTrace();
		}
		//String str = "{\"status\":" + state + ",\"id\": \"" + id +"\"}";
		//json-simple lib 활용
		
		JSONObject
		
		return str;
	}
	
	
}
