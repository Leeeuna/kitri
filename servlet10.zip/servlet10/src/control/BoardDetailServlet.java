package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.service.BoardService;


public class BoardDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BoardService service;
	public BoardDetailServlet() {
		service = new BoardService();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("boarddetailServlet의 doGet() 호출됨");
		response.setContentType("text/html; charset=UTF-8");
		String str_board_no = request.getParameter("board_no");
		int board_no = Integer.parseInt("str_board_no");
		int parent_no = Integer.parseInt("parent_no");
		String board_subject = request.getParameter("board_subject");
		String board_writer = request.getParameter("board_writer");
		String str_board_time = request.getParameter("board_time");
		Date board_time = format.parse("str_board_time");
		String board_content = request.getParameter("board_content");

		

	    PrintWriter out = response.getWriter();
	   
	    
	    String view = "/boarddetailresult.jsp";
	    
	    request.setAttribute("board_no", board_no);
	    
	  
	    RequestDispatcher dispatcher = request.getRequestDispatcher(view);
	    dispatcher.forward(request, response);    
	}
	
	

}
