package javaSwing;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class JButtonEx {
	public static void main(String[] args) {
		JFrame frame = new JFrame("euna Swing GUI");
		JPanel panel = new JPanel();
		JLabel label = new JLabel("ID : ");
		JLabel idlabel = new JLabel("ID : " + "euna");
		JTextField textfield = new JTextField(10);
		JButton button = new JButton("Button");
		String str = null;
		
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String str = textfield.getText();
				idlabel.setText("ID : "+ str);
				System.out.println(str);
			}
		});
		
		
		panel.add(label);
		panel.add(textfield);
		panel.add(button);
		panel.add(idlabel);
		frame.setContentPane(panel);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//X������ ����
		frame.setSize(400,400);
		frame.setVisible(true);
	}
}
