package javaSwing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class lotto {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					lotto window = new lotto();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public lotto() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 561, 394);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label1 = new JLabel("?");
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		label1.setFont(new Font("����", Font.BOLD, 30));
		label1.setBounds(58, 74, 86, 77);
		frame.getContentPane().add(label1);
		
		JLabel label2 = new JLabel("?");
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		label2.setFont(new Font("����", Font.BOLD, 30));
		label2.setBounds(200, 74, 86, 77);
		frame.getContentPane().add(label2);
		
		JLabel label3 = new JLabel("?");
		label3.setHorizontalAlignment(SwingConstants.CENTER);
		label3.setFont(new Font("����", Font.BOLD, 30));
		label3.setBounds(344, 74, 86, 77);
		frame.getContentPane().add(label3);
		
		JButton btnNewButton = new JButton("Press");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int[] arr = new int[3];
				arr[0] =(int)(Math.random()*45) + 1;
				arr[1] =(int)(Math.random()*45) + 1;
				arr[2] =(int)(Math.random()*45) + 1;
				
		
				
				label1.setText(Integer.toString(arr[0]));
				label2.setText(Integer.toString(arr[1]));
				label3.setText(Integer.toString(arr[2]));
				System.out.println("����Ϸ�");
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 30));
		btnNewButton.setBounds(87, 184, 306, 77);
		frame.getContentPane().add(btnNewButton);
	}

}
