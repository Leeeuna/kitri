package com.studybb.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.studybb.exception.NotFoundException;
import com.studybb.vo.Study;



public class StudyDAO {

	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public List<Study> select(int startRow, int endRow) throws NotFoundException {

		List<Study> list = new ArrayList<Study>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "C##ORACLE_USER";
			String password = "dmsk";
			con = DriverManager.getConnection(url, user, password);
			String selectSQL = "";
			pstmt = con.prepareStatement(selectSQL);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();	
			while (rs.next()) {
				int study_no = rs.getInt("study_no");
				String mem_id = rs.getString("mem_id");
				String study_leader_intro = rs.getString("study_leader_intro");
				String study_title = rs.getString("study_title");
				String study_area = rs.getString("study_area");
				Date study_start = rs.getDate("study_start");
				int study_week = rs.getInt("study_week");
				Date study_due = rs.getDate("study_due");
				String study_content = rs.getString("study_content");
				String study_tag = rs.getString("study_tag");
				Date study_upload = rs.getDate("study_upload");
				int study_type = rs.getInt("study_type");
				int study_price = rs.getInt("study_price");
				int study_cap = rs.getInt("study_cap");
				
				// 대입
				Study study = new Study();
				list.add(study);
			}
			if(list.size() == 0) {
				throw new NotFoundException("게시목록이 없습니다.");
			}
		} catch (Exception e) {
			throw new NotFoundException(e.getMessage());
		} finally {
			closeConnection();
		}
		return list;
		
	}
	
//	public Board selectByBoardNo(int no, String mode) throws NotFoundException {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "C##ORACLE_USER";
//			String password = "dmsk";
//			con = DriverManager.getConnection(url, user, password);
//			String selectSQL = "SELECT * FROM board WHERE board_no = ?";
//			pstmt = con.prepareStatement(selectSQL);
//			pstmt.setInt(1, no);
//			rs = pstmt.executeQuery();	
//
//			if (rs.next()) {
//				int board_no = rs.getInt("board_no");
//				int parent_no = rs.getInt("parent_no");
//				String board_subject = rs.getString("board_subject");
//				String board_writer = rs.getString("board_writer");
//				String board_content = rs.getString("board_content");
//				Date board_time = rs.getDate("board_time");
//				String board_pwd = rs.getString("board_pwd");
//
//				Board board = new Board(board_no, parent_no, 
//						board_subject, board_writer, board_content, board_time);
//				
//				if(mode.equals("edit"))	
//					board.setBoard_pwd(board_pwd);
//				
//				return board;
//			}
//			throw new NotFoundException("게시목록이 없습니다.");
//		} catch (Exception e) {
//			throw new NotFoundException(e.getMessage());
//		} finally {
//			closeConnection();
//		}
//	}
//	
//	public void insert(Board board) throws NotFoundException {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "C##ORACLE_USER";
//			String password = "dmsk";
//			con = DriverManager.getConnection(url, user, password);
//			String selectSQL = "INSERT INTO board(BOARD_NO, PARENT_NO, BOARD_SUBJECT, "
//					+ "BOARD_WRITER, BOARD_CONTENT, BOARD_TIME, BOARD_PWD) "
//					+ "VALUES (board_seq.NEXTVAL, ?, ?, ?, ?, SYSDATE, ?)";
//			pstmt = con.prepareStatement(selectSQL);
//			if(board.getParent_no() == 0) {
//				pstmt.setObject(1, null);
//			} else {
//
//				pstmt.setInt(1, board.getParent_no());
//			}
//			pstmt.setString(2, board.getBoard_subject());
//			pstmt.setString(3, board.getBoard_writer());
//			pstmt.setString(4, board.getBoard_content());
//			pstmt.setString(5, board.getBoard_pwd());
//			rs = pstmt.executeQuery();	
//			if (rs.next()) {
//				return;		
//			}
//			throw new NotFoundException("게시물 등록 실패");
//		} catch (Exception e) {
//			throw new NotFoundException(e.getMessage());
//		} finally {
//			closeConnection();
//		}
//	}
	
	public void closeConnection() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
