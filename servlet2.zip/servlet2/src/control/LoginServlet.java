package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		int state = 0;
		
		 String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	      String DB_USER = "C##ORACLE_USRER";
	      String DB_PW = "dmsk";
	      
	      Connection conn = null;
	      ResultSet rs = null;	
	      PreparedStatement pstmt = null ;
	      
	      String selectSQL = "SELECT * FROM customer WHERE id=?";
			
	      try {
	         Class.forName("oracle.jdbc.driver.OracleDriver");
	         conn = DriverManager.getConnection(
		               DB_URL, 
		               DB_USER, 
		               DB_PW);
	        pstmt = conn.prepareStatement(selectSQL);
				
				pstmt.setString(1,id);
				rs = pstmt.executeQuery(selectSQL);
				
				if (rs.next()) {
		        	if(pwd.equals(rs.getString("pwd"))){// 로그인 성공
		        		state = 1;
					}else {
						state = -1;
					}
					
		         }
	      }catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	         try {
	        	 if (pstmt != null && !pstmt.isClosed())
	                 pstmt.close();
	              if (rs != null && !rs.isClosed())
	                 pstmt.close();
	           } catch (SQLException e) {
	              e.printStackTrace();
	           }
	        }

		
		//1.응답형식 지정하기. MIME값 활용
				response.setContentType("text/html;charset=utf-8");
				//2.응답출력스트림 얻기
				PrintWriter out = response.getWriter();
				//3.응답하기
				//out.print(id + "님 로그인 성공");
				
				String str = "{\"status\":" + state + ",\"id\": \"" + id +"\"}";
				out.print(str);
	}

}
