package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchZipServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public SearchZipServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	      String DB_USER = "C##ORACLE_USRER";
	      String DB_PW = "dmsk";
	      
	      Connection conn = null;
	      ResultSet rs = null;	
	      PreparedStatement pstmt = null ;
	      
	      String selectSQL = "select zipcode,sido ||' ' || sigungu ||NVL2(sigungu,' ', '')|| eupmyun ||NVL2(eupmyun,' ', '')|| doro ||' '||building1|| decode(building2,'0','','-'||building2)||' '||'('||dong || ri|| decode(building, '', '', ',' || building) ||')' ||chr(13)||chr(10)|| sido ||' ' || sigungu ||NVL2(sigungu,' ', '')|| eupmyun ||NVL2(eupmyun,' ', '')||dong || ri||' '|| zibun1|| decode(zibun2, '0', '', '-'||zibun2) ||' '||'('||decode(building, '', '', ',' || building) ||')'  from post where (doro || ' ' || building1 || decode(building2,'0','','-'||building2)) = '세종로 2511';";
			
	      try {
	         Class.forName("oracle.jdbc.driver.OracleDriver");
	         conn = DriverManager.getConnection(
		               DB_URL, 
		               DB_USER, 
		               DB_PW);
	        pstmt = conn.prepareStatement(selectSQL);
				

	      }catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	         try {
	        	 if (pstmt != null && !pstmt.isClosed())
	                 pstmt.close();
	              if (rs != null && !rs.isClosed())
	                 pstmt.close();
	           } catch (SQLException e) {
	              e.printStackTrace();
	           }
	        }

		
//		//1.응답형식 지정하기. MIME값 활용
//				response.setContentType("text/html;charset=utf-8");
//				//2.응답출력스트림 얻기
//				PrintWriter out = response.getWriter();
//				//3.응답하기
//				//out.print(id + "님 로그인 성공");
//				
//				String str = "{\"status\":" + state + ",\"id\": \"" + id +"\"}";
//				out.print(str);
	}

}
