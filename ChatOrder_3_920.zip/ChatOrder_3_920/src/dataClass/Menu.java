package dataClass;

public class Menu {

	private int menuNum;		// �޴� ��ȣ
	private String menuName;	// �޴� �̸�
	private int price;			// ����
	private int priceTall;		// Tall ����
	private int priceGrande;	// Grande ����
	
	
	public Menu(int menuNum, String menuName, int price, int priceTall, int priceGrande){
		this.menuNum = menuNum;
		this.menuName = menuName;
		this.price = price;
		this.priceTall = priceTall;
		this.priceGrande = priceGrande;
	}
	public int getMenuNum() {
		return menuNum;
	}
	public void setMenuNum(int menuNum) {
		this.menuNum = menuNum;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPriceTall() {
		return priceTall;
	}
	public void setPriceTall(int priceTall) {
		this.priceTall = priceTall;
	}
	public int getPriceGrande() {
		return priceGrande;
	}
	public void setPriceGrande(int priceGrande) {
		this.priceGrande = priceGrande;
	}
	
}
