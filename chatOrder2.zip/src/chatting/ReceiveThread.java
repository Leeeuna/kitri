package chatting;

import java.net.ServerSocket;
import java.net.Socket;

import javafx.application.Platform;

public class ReceiveThread implements Runnable {

	private ServerSocket serverSocket;
	
	public ReceiveThread(MainServer ms) {
		this.serverSocket = ms.serverSocket;
	}

	@Override
	public void run() {
		Platform.runLater(()->{
			displayText("[���� ����]");
		});
		
		while(true) {
			try {
				// ���� ����, client Ȯ��
				Socket socket = serverSocket.accept();
				String message = "[���� ����: " + socket.getRemoteSocketAddress() 
					+ ": " + Thread.currentThread().getName() + "]";
				Platform.runLater(()->displayText(message));
				
				Client client = new Client(socket);
				connections.add(client);
				Platform.runLater(()->display
			} 
		}
	}

}
