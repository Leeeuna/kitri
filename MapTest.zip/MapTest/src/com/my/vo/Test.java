package com.my.vo;

public class Test {

}
